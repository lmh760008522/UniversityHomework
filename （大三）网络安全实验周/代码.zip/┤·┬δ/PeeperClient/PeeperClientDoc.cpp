#include "stdafx.h"
#include "PeeperClient.h"
#include "PeeperClientDoc.h"
#include "PeeperFrm.h"
#include "PeeperSetDlg.h"
#include "../peeperlib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CPeeperClientDoc, CDocument)

BEGIN_MESSAGE_MAP(CPeeperClientDoc, CDocument)
	//{{AFX_MSG_MAP(CPeeperClientDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CPeeperClientDoc::CPeeperClientDoc()
{
}

CPeeperClientDoc::~CPeeperClientDoc()
{
}

BOOL CPeeperClientDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	CPeeperSetDlg dlgSet;
	if(dlgSet.DoModal() != IDOK)
	{
		return FALSE;
	}
	m_strIP = dlgSet.m_strIP;
	m_uPort = dlgSet.m_uPort;
	m_nBits = dlgSet.m_nBits;
	m_nSpeed = dlgSet.m_nSpeed;

	return TRUE;
}

#define PEEPER_VERSION	_T("PPV1.1")

void CPeeperClientDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << PEEPER_SERVER_VER_15;
		ar << m_strIP;
		ar << m_uPort;
		ar << m_nBits;
		ar << m_nSpeed;
	}
	else
	{
		CString strVer;
		ar >> strVer;
		if((strVer.CompareNoCase(PEEPER_VERSION) == 0) ||
			(strVer.CompareNoCase(PEEPER_SERVER_VER_15) == 0))
		{
			ar >> m_strIP;
			ar >> m_uPort;
			ar >> m_nBits;
			ar >> m_nSpeed;
		}
		else
		{
			m_strIP = _T("127.0.0.1");
			m_uPort = PL_PEEPER_PORT;
			m_nBits = 4;
			m_nSpeed = 1000;
		}
	}
}

void CPeeperClientDoc::OnCloseDocument() 
{
	CDocument::OnCloseDocument();
	((CMainFrame *)AfxGetApp()->m_pMainWnd)->OnFileClose();
}
