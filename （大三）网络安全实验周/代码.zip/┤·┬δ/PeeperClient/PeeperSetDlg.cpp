#include "stdafx.h"
#include "peeperclient.h"
#include "PeeperSetDlg.h"
#include "../peeperlib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CPeeperSetDlg::CPeeperSetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPeeperSetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPeeperSetDlg)
	//}}AFX_DATA_INIT
}

void CPeeperSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPeeperSetDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPeeperSetDlg, CDialog)
	//{{AFX_MSG_MAP(CPeeperSetDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CPeeperSetDlg::OnOK() 
{
	GetDlgItemText(IDC_EDIT_IP, m_strIP);
	m_uPort = GetDlgItemInt(IDC_EDIT_PORT);
	m_nBits = GetDlgItemInt(IDC_EDIT_BITS);
	m_nSpeed = GetDlgItemInt(IDC_EDIT_SPEED);
	
	CDialog::OnOK();
}

BOOL CPeeperSetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetDlgItemText(IDC_EDIT_IP, _T("127.0.0.1"));
	SetDlgItemInt(IDC_EDIT_PORT, PL_PEEPER_PORT);
	SetDlgItemText(IDC_EDIT_BITS, _T("4"));
	SetDlgItemInt(IDC_EDIT_SPEED, 1000);

	((CEdit *)GetDlgItem(IDC_EDIT_SPEED))->SetLimitText(6);
	((CEdit *)GetDlgItem(IDC_EDIT_BITS))->SetLimitText(2);
	
	return TRUE;
}
