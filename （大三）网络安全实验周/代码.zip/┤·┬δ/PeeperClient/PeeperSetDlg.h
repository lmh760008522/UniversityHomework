#ifndef __PEEPER_SET_H__
#define __PEEPER_SET_H__

#include "resource.h"

class CPeeperSetDlg : public CDialog
{
public:
	CPeeperSetDlg(CWnd* pParent = NULL);
	//{{AFX_DATA(CPeeperSetDlg)
	enum { IDD = IDD_DIALOG_SET };
	//}}AFX_DATA
	//{{AFX_VIRTUAL(CPeeperSetDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL
public:
	CString m_strIP;
	UINT m_uPort;
	int  m_nBits;
	int  m_nSpeed;

protected:
	//{{AFX_MSG(CPeeperSetDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // __PEEPER_SET_H__
