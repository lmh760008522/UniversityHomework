//������

#include "stdafx.h"
#include "PeeperClient.h"
#include "PeeperFrm.h"
#include "PeeperWnd.h"
#include "PeeperClientDoc.h"

#include "../peeperzip.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CMainClientWnd::CMainClientWnd()
{
	m_bStretch = FALSE;
}

CMainClientWnd::~CMainClientWnd()
{
}

BEGIN_MESSAGE_MAP(CMainClientWnd, CWnd)
	//{{AFX_MSG_MAP(CMainClientWnd)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CMainClientWnd::SetBkBitmap(HBITMAP hBmp, BOOL bStretch)
{
	if(m_memDC.m_hDC != NULL)
	{
		m_memDC.DeleteDC();
	}
	m_memDC.CreateCompatibleDC(NULL);
	BITMAP bm;
	::GetObject(hBmp, sizeof(bm), &bm);
	m_szBmp.cx = bm.bmWidth;
	m_szBmp.cy = bm.bmHeight;
	::SelectObject(m_memDC.m_hDC, hBmp);
	m_bStretch = bStretch;

	return TRUE;
}

BOOL CMainClientWnd::PaintBmp()
{
	CClientDC dc(this);
	if(m_memDC.m_hDC != NULL)
	{
		CRect rect;
		GetClientRect(&rect);
		if(m_bStretch)
		{
			dc.SetStretchBltMode(COLORONCOLOR);
			dc.StretchBlt(rect.left, rect.top, rect.Width(), rect.Height(),
				&m_memDC, 0, 0, m_szBmp.cx, m_szBmp.cy, SRCCOPY);
		}
		else
		{
			int nXn = rect.Width()/m_szBmp.cx;
			int nYn = rect.Height()/m_szBmp.cy;
			if(rect.Width()%m_szBmp.cx > 0)
				nXn ++;
			if(rect.Height()%m_szBmp.cy > 0)
				nYn ++;
			for(int i = 0; i < nXn; i ++)
			{
				for(int j = 0; j < nYn; j ++)
				{
					int w = min(m_szBmp.cx, rect.Width() - i*m_szBmp.cx);
					int h = min(m_szBmp.cy, rect.Height() - j*m_szBmp.cy);
					dc.BitBlt(i*m_szBmp.cx, j*m_szBmp.cy, w, h, &m_memDC, 0, 0, SRCCOPY);
				}
			}
		}
	}
	return TRUE;
}

void CMainClientWnd::OnPaint()
{
	CPaintDC dc(this);
	PaintBmp();
}

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_GETMINMAXINFO()
	ON_WM_CREATE()
	ON_WM_MDIACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CChildFrame::CChildFrame()
{
}

CChildFrame::~CChildFrame()
{
}

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	ModifyStyleEx(WS_EX_CLIENTEDGE, WS_EX_STATICEDGE);

	CRect rect;
	GetWindowRect(&rect);
	rect.right += 1;
	rect.bottom += 1;
	MoveWindow(rect);

	return 0;
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	return CMDIChildWnd::PreCreateWindow(cs);
}

void CChildFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI)
{
	lpMMI->ptMaxSize.x		= 3200;
	lpMMI->ptMaxSize.y		= 2400;
	lpMMI->ptMaxTrackSize.x = 3200;
	lpMMI->ptMaxTrackSize.y = 2400;

	CMDIChildWnd::OnGetMinMaxInfo(lpMMI);
}

void CChildFrame::OnMDIActivate(BOOL bActivate, CWnd* pActivateWnd, CWnd* pDeactivateWnd)
{
	CMDIChildWnd::OnMDIActivate(bActivate, pActivateWnd, pDeactivateWnd);
	CMainFrame *pMainWnd = (CMainFrame *)AfxGetMainWnd();
	if(pMainWnd)
	{
		pMainWnd->OnFileNew();
	}
}

CPeeperBar::CPeeperBar()
{
}

CPeeperBar::~CPeeperBar()
{
}

BEGIN_MESSAGE_MAP(CPeeperBar, CDialogBar)
	//{{AFX_MSG_MAP(CPeeperBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_BTN_COMMAND_EXEC,			OnMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_FILE_CLOSESERVER,	OnUpdateMenuCommand)
	ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_BTN_COMPUTER_EXEC,		OnMenuCommand)
	ON_BN_CLICKED(IDC_BTN_FILE_EXEC,			OnMenuCommand)
	ON_BN_CLICKED(IDC_BTN_FILE_SOURCE,			OnMenuCommand)
	ON_BN_CLICKED(IDC_BTN_FILE_TARGET,			OnMenuCommand)
	ON_CBN_SELCHANGE(IDC_COMBO_FILE_TYPE,		OnMenuCommand)
	ON_COMMAND(ID_FILE_CLOSESERVER,				OnMenuCommand)
	ON_COMMAND(ID_VIEW_SEND,					OnMenuCommand)
	ON_COMMAND(ID_FILE_MANAGE,					OnMenuCommand)
	ON_COMMAND(ID_VIEW_COMPUTER,				OnMenuCommand)
	ON_COMMAND(ID_TOOL_DIBVIEW_FULL,			OnMenuCommand)
	ON_COMMAND(ID_OPTION_PAUSE,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_MOUSE_MOVE,			OnMenuCommand)
	ON_COMMAND(ID_OPTION_MOUSE_LBUTTON,			OnMenuCommand)
	ON_COMMAND(ID_OPTION_MOUSE_RBUTTON,			OnMenuCommand)
	ON_COMMAND(ID_OPTION_MOUSE_LDBLCLK,			OnMenuCommand)
	ON_COMMAND(ID_OPTION_MOUSE_RDBLCLK,			OnMenuCommand)
	ON_COMMAND(ID_OPTION_KEY,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_DIB,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_1BITS,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_4BITS,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_8BITS,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_24BITS,				OnMenuCommand)
	ON_COMMAND(ID_OPTION_NOZIP,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_LZ77,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_LZW,					OnMenuCommand)
//	ON_COMMAND(ID_OPTION_JPEG,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_LZSS,					OnMenuCommand)
	ON_COMMAND(ID_OPTION_ARI,					OnMenuCommand)
	ON_COMMAND(ID_HELP_REGISTER,				OnMenuCommand)
	ON_COMMAND(ID_HELP_HELP,					OnMenuCommand)

	ON_UPDATE_COMMAND_UI(ID_VIEW_SEND,				OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_FILE_MANAGE,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_VIEW_COMPUTER,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_TOOL_DIBVIEW_FULL,		OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_PAUSE,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_MOUSE_MOVE,		OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_MOUSE_LBUTTON,	OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_MOUSE_RBUTTON,	OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_MOUSE_LDBLCLK,	OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_MOUSE_RDBLCLK,	OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_KEY,				OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_DIB,				OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_1BITS,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_4BITS,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_8BITS,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_24BITS,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_NOZIP,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_LZ77,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_LZW,				OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_JPEG,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_LZSS,			OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_OPTION_ARI,				OnUpdateMenuCommand)

//��Ϣ��
	ON_UPDATE_COMMAND_UI(ID_STATUS_CONN_INFO,		OnUpdateMenuCommand)
	ON_UPDATE_COMMAND_UI(ID_STATUS_TIME,			OnUpdateMenuCommand)

	ON_WM_DRAWITEM()
	ON_WM_MEASUREITEM()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,
	ID_STATUS_CONN_INFO,
	ID_STATUS_TIME,
};

CMainFrame::CMainFrame()
{
	m_bIsFullScreen = FALSE;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	//�ı���Ϣ��������
	UINT nID = 0;
	UINT nStyle = 0;
	int cxWidth = 0;
	m_wndStatusBar.GetPaneInfo(1, nID, nStyle, cxWidth);
	m_wndStatusBar.SetPaneInfo(1, nID, nStyle, 200);

	UINT nStyle1 = 0;
	m_wndStatusBar.GetPaneInfo(0, nID, nStyle1, cxWidth);
	m_wndStatusBar.SetPaneInfo(0, nID, nStyle, 200);

	m_wndStatusBar.GetPaneInfo(2, nID, nStyle, cxWidth);
	m_wndStatusBar.SetPaneInfo(2, nID, nStyle | SBPS_STRETCH, 0);

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	if (!m_wndCommand.Create(this, IDD_DLGBAR_COMMAND,
		CBRS_TOP | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_HIDE_INPLACE,
		IDD_DLGBAR_COMMAND))
	{
		TRACE0("Failed to create dialog bar m_wndCommand\n");
		return -1;		// fail to create
	}

	if (!m_wndFile.Create(this, IDD_DLGBAR_FILE,
		CBRS_BOTTOM | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_HIDE_INPLACE,
		IDD_DLGBAR_FILE))
	{
		TRACE0("Failed to create dialog bar m_wndFile\n");
		return -1;		// fail to create
	}

	if (!m_wndComputer.Create(this, IDD_DLGBAR_COMPUTER,
		CBRS_TOP | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_HIDE_INPLACE,
		IDD_DLGBAR_COMPUTER))
	{
		TRACE0("Failed to create dialog bar m_wndFile\n");
		return -1;		// fail to create
	}

	if (!m_wndDibView.Create(this) ||
		!m_wndDibView.LoadToolBar(IDR_TOOLBAR_DIBVIEW))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	m_wndDibView.ModifyStyle(0, TBSTYLE_FLAT);

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndCommand.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
	m_wndFile.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
	m_wndComputer.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
	m_wndDibView.EnableDocking(CBRS_ALIGN_ANY);

	EnableDocking(CBRS_ALIGN_ANY);

	DockControlBar(&m_wndToolBar);
	DockControlBar(&m_wndFile, AFX_IDW_DOCKBAR_BOTTOM);

	RecalcLayout();

	CRect rcMain;
	CRect rcTool;
	GetWindowRect(&rcMain);
	m_wndToolBar.GetWindowRect(&rcTool);
	rcMain.top = rcTool.top;
	rcMain.left = rcTool.right;
	rcMain.bottom = rcMain.top + rcTool.Height();
	DockControlBar(&m_wndCommand, AFX_IDW_DOCKBAR_TOP, &rcMain);
	RecalcLayout();

	GetWindowRect(&rcMain);
	m_wndCommand.GetWindowRect(&rcTool);
	rcMain.top = rcTool.top;
	rcMain.left = rcTool.right;
	rcMain.bottom = rcMain.top + rcTool.Height();
	DockControlBar(&m_wndComputer, AFX_IDW_DOCKBAR_TOP, &rcMain);
	RecalcLayout();

	m_wndToolBar.SetWindowText(_T("��������"));
	m_wndCommand.SetWindowText(_T("�������"));
	m_wndFile.SetWindowText(_T("�ļ�����������"));
	m_wndComputer.SetWindowText(_T("���Կ��ƹ�����"));

	ShowControlBar(&m_wndCommand, FALSE, FALSE);
	ShowControlBar(&m_wndComputer, FALSE, FALSE);
	ShowControlBar(&m_wndFile, FALSE, FALSE);
	ShowControlBar(&m_wndDibView, FALSE, FALSE);

	//init some data
	CComboBox *pCombo = (CComboBox *)(m_wndCommand.GetDlgItem(IDC_COMBO_COMMAND_TYPE));
	if(pCombo)
	{
		int nItem = pCombo->AddString(_T("��Ϣ"));
		pCombo->SetItemData(nItem, PL_MSG);
		nItem = pCombo->AddString(_T("����"));
		pCombo->SetItemData(nItem, PL_FUNC_EXEC);
		pCombo->SetCurSel(0);
	}
	pCombo = (CComboBox *)(m_wndFile.GetDlgItem(IDC_COMBO_FILE_TYPE));
	if(pCombo)
	{
		int nItem = pCombo->AddString(_T("������Զ��"));
		pCombo->SetItemData(nItem, PL_FUNC_FILE_COPY_S);
		nItem = pCombo->AddString(_T("����������"));
		pCombo->SetItemData(nItem, PL_FUNC_FILE_COPY_C);
		nItem = pCombo->AddString(_T("ɾ���ļ�"));
		pCombo->SetItemData(nItem, PL_FUNC_FILE_DELETE);
		nItem = pCombo->AddString(_T("�ƶ��ļ�"));
		pCombo->SetItemData(nItem, PL_FUNC_FILE_MOVE);
		pCombo->SetCurSel(0);
	}

	pCombo = (CComboBox *)(m_wndComputer.GetDlgItem(IDC_COMBO_COMPUTER_TYPE));
	if(pCombo)
	{
		int nItem = pCombo->AddString(_T("ע��"));
		pCombo->SetItemData(nItem, PL_FUNC_EXITWIN+0);
		nItem = pCombo->AddString(_T("����"));
		pCombo->SetItemData(nItem, PL_FUNC_EXITWIN+1);
		nItem = pCombo->AddString(_T("�ػ�"));
		pCombo->SetItemData(nItem, PL_FUNC_EXITWIN+2);
		nItem = pCombo->AddString(_T("����"));
		pCombo->SetItemData(nItem, PL_FUNC_EXITWIN+3);
		nItem = pCombo->AddString(_T("����"));
		pCombo->SetItemData(nItem, PL_FUNC_EXITWIN+4);
		pCombo->SetCurSel(0);
	}

	//���ñ�����ͨ��һ��ͼ��
	m_wndClientWnd.SubclassWindow(m_hWndMDIClient);
	HBITMAP hBmp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_MAINCLIENT_BK));
	m_wndClientWnd.SetBkBitmap(hBmp, FALSE);
	::DeleteObject(hBmp);

	//�����Լ��ķ��˵�
	m_hPeeperMenu.SetBkImage(IDB_BITMAP_MENU_BK);
//	//����ϵͳ�˵�
//	m_hPeeperSysMenu.AttachMenu(GetSystemMenu(FALSE)->GetSafeHmenu(), 0, CSize(0, 0));
#if 0
	HGLOBAL hDib = ::PL_ReadDataFromFile(_T("d:\\test.doc"));
#endif
#if 0 //Ϊ��C_LZSS����
	HGLOBAL hUnZip = PL_LZSS_Zip(hDib);
	HGLOBAL hZip = PL_LZSS_UnZip(hUnZip);
#endif //Ϊ��C_LZSS����

#if 0//Ϊ��C_ARI����
	HGLOBAL hUnZip = PL_ARI_Zip(hDib);
	HGLOBAL hZip = PL_ARI_UnZip(hUnZip);
#endif//Ϊ��C_ARI����
#if 0 //Ϊ��LZ77����
	HGLOBAL hZip = ::PL_LZ77_Zip(hDib);
	HGLOBAL hUnZip = ::PL_LZ77_UnZip(hZip);
#endif
#if 0 // Ϊ��LZW����
	HGLOBAL hZip = PL_LZW_Zip(hDib);
	HGLOBAL hUnZip = PL_LZW_UnZip(hZip);
	PL_WriteDataToFile(_T("d:\\test_lzw.doc"), hUnZip);
#endif
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	return CMDIFrameWnd::PreCreateWindow(cs);
}

BOOL CMainFrame::PeeperMenuAttach(HMENU hMenu)
{
	BOOL bRet = m_hPeeperMenu.AttachMenu(hMenu, IDR_MAINFRAME, CSize(16, 15));
	m_hPeeperMenu.AddToolBar(IDR_TOOLBAR_DIBVIEW, CSize(16, 15));
	return bRet;
}

BOOL CMainFrame::PeeperClientMenuAttach(HMENU hMenu)
{
	return m_hPeeperClientMenu.AttachMenu(hMenu, IDR_MAINFRAME, CSize(16, 15));
}

int CMainFrame::GetClientCount()
{
	int nCount = 0;
	POSITION pos = AfxGetApp()->GetFirstDocTemplatePosition();
	while(pos)
	{
		CDocTemplate* pTemplate = (CDocTemplate*)AfxGetApp()->GetNextDocTemplate(pos);
		POSITION pos2 = pTemplate->GetFirstDocPosition();
		while(pos2)
		{
			CDocument * pDocument = pTemplate->GetNextDoc(pos2);
			if(pDocument)
			{
				nCount ++;
			}
		}
		break ;
	}
	return nCount;
}

CChildFrame *CMainFrame::GetCurFrame()
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->m_pMainWnd;
	if(pFrame)
	{
		return (CChildFrame *)pFrame->GetActiveFrame();
	}
	return NULL;
}

CPeeperWnd *CMainFrame::GetCurPeeperWnd()
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->m_pMainWnd;
	if(pFrame)
	{
		CChildFrame *pChild = (CChildFrame *)pFrame->GetActiveFrame();
		if(pChild)
		{
			return (CPeeperWnd *)pChild->GetActiveView();
		}
	}
	return NULL;
}

CPeeperClientDoc *CMainFrame::GetCurPeeperDoc()
{
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->m_pMainWnd;
	if(pFrame)
	{
		CChildFrame *pChild = (CChildFrame *)pFrame->GetActiveFrame();
		if(pChild)
		{
			return (CPeeperClientDoc *)pChild->GetActiveDocument();
		}
	}
	return NULL;
}

void CMainFrame::OnFileClose()
{
	CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
	if(!pPeeperWnd)
	{
		ShowControlBar(&m_wndCommand, FALSE, FALSE);
		ShowControlBar(&m_wndComputer, FALSE, FALSE);
		ShowControlBar(&m_wndFile, FALSE, FALSE);
		ShowControlBar(&m_wndDibView, FALSE, FALSE);
		RecalcLayout();
	}
}

void CMainFrame::OnFileNew()
{
	return ;
}

void CMainFrame::OnMenuCommand()
{
	const MSG *pMsg = CWnd::GetCurrentMessage();
	if(pMsg != NULL)
	{
		int nMenuID = (int)(LOWORD(pMsg->wParam));
		CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
		switch(nMenuID)
		{
		case ID_VIEW_SEND:
			{
				ShowControlBar(&m_wndCommand, !(m_wndCommand.IsWindowVisible()), TRUE);
			}
			break ;
		case ID_FILE_MANAGE:
			{
				ShowControlBar(&m_wndFile, !(m_wndFile.IsWindowVisible()), TRUE);
			}
			break ;
		case ID_VIEW_COMPUTER:
			{
				ShowControlBar(&m_wndComputer, !(m_wndComputer.IsWindowVisible()), TRUE);
			}
			break ;
		case ID_TOOL_DIBVIEW_FULL:
			{
				ShowControlBar(&m_wndDibView, !(m_wndDibView.IsWindowVisible()), TRUE);
				OnFullScreen();
			}
			break ;
		case ID_FILE_CLOSESERVER:
			{
				if(pPeeperWnd && pPeeperWnd->GetState())
				{
					pPeeperWnd->CloseServer();
				}
			}
			break ;
		case ID_OPTION_PAUSE:
			{
				if(pPeeperWnd)
				{
					BOOL bPause = pPeeperWnd->IsPause();
					if(bPause)
					{
						pPeeperWnd->Resume();
					}
					else
					{
						pPeeperWnd->Pause();
					}
				}
			}
			break ;
		case ID_OPTION_MOUSE_MOVE:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_MOVE);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_MOUSE_MOVE, !bOld);
				}
			}
			break ;
		case ID_OPTION_MOUSE_LBUTTON:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_LBUTTON);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_MOUSE_LBUTTON, !bOld);
				}
			}
			break ;
		case ID_OPTION_MOUSE_RBUTTON:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_RBUTTON);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_MOUSE_RBUTTON, !bOld);
				}
			}
			break ;
		case ID_OPTION_MOUSE_LDBLCLK:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_LDBLCLK);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_MOUSE_LDBLCLK, !bOld);
				}
			}
			break ;
		case ID_OPTION_MOUSE_RDBLCLK:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_RDBLCLK);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_MOUSE_RDBLCLK, !bOld);
				}
			}
			break ;
		case ID_OPTION_KEY:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_KEY);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_KEY, !bOld);
				}
			}
			break ;
		case ID_OPTION_DIB:
			{
				if(pPeeperWnd)
				{
					BOOL bOld = pPeeperWnd->GetEnableFlag(PL_ENABLE_DIB);
					pPeeperWnd->SetEnableFlag(PL_ENABLE_DIB, !bOld);
				}
			}
			break ;
		case ID_OPTION_1BITS:
		case ID_OPTION_4BITS:
		case ID_OPTION_8BITS:
		case ID_OPTION_24BITS:
			{
				if(pPeeperWnd)
				{
					pPeeperWnd->SetColorType(PL_ColorType(nMenuID - ID_OPTION_1BITS));
				}
			}
			break ;
		case ID_OPTION_NOZIP:
		case ID_OPTION_LZ77:
		case ID_OPTION_LZW:
		case ID_OPTION_JPEG:
		case ID_OPTION_LZSS:
		case ID_OPTION_ARI:
			{
				if(pPeeperWnd)
				{
					pPeeperWnd->SetZipType(PL_ZipType(nMenuID - ID_OPTION_NOZIP));
				}
			}
			break ;
		case IDC_BTN_COMMAND_EXEC:
			{
				OnExecCommand();
			}
			break ;
		case IDC_BTN_COMPUTER_EXEC:
			{
				OnExecComputer();
			}
			break ;
		case IDC_BTN_FILE_EXEC:
			{
				OnExecFile();
			}
			break ;
		case IDC_BTN_FILE_SOURCE:
			{
			}
			break ;
		case IDC_BTN_FILE_TARGET:
			{
			}
			break ;
		case IDC_COMBO_FILE_TYPE:
			{
				;
			}
			break ;
		case ID_HELP_HELP:
			{
				TCHAR chApp[255];
				memset(chApp, 0, sizeof(TCHAR)*255);
				GetModuleFileName(NULL, chApp, 255);
				CString strApp = CString(chApp);
				int nPos = strApp.ReverseFind(_T('\\'));
				if(nPos > 0)
				{
					strApp = strApp.Left(nPos);
				}
				::ShellExecute(NULL, "open", "Readme.txt", NULL, strApp,
					SW_SHOWNORMAL);
			}
			break ;
		case ID_HELP_REGISTER:
			{
				CRegisterDlg dlgReg;
				dlgReg.DoModal();
				dlgReg.m_strUserName;
				dlgReg.m_strCode;
			}
			break ;
		default :
			break ;
		}
	}
}

void CMainFrame::OnUpdateMenuCommand(CCmdUI* pCmdUI)
{
	CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
	switch(pCmdUI->m_nID)
	{
	case ID_VIEW_SEND:
		{
			if(!pPeeperWnd)
			{
				pCmdUI->Enable(FALSE);
			}
			pCmdUI->SetCheck(m_wndCommand.IsWindowVisible());
		}
		break ;
	case ID_FILE_MANAGE:
		{
			if(!pPeeperWnd)
			{
				pCmdUI->Enable(FALSE);
			}
			pCmdUI->SetCheck(m_wndFile.IsWindowVisible());
		}
		break ;
	case ID_VIEW_COMPUTER:
		{
			if(!pPeeperWnd)
			{
				pCmdUI->Enable(FALSE);
			}
			pCmdUI->SetCheck(m_wndComputer.IsWindowVisible());
		}
		break ;
	case ID_TOOL_DIBVIEW_FULL:
		{
			if(!pPeeperWnd)
			{
				pCmdUI->Enable(FALSE);
				ShowControlBar(&m_wndDibView, FALSE, FALSE);
			}
			else
			{
				pCmdUI->Enable(TRUE);
			}
		}
		break ;
	case ID_FILE_CLOSESERVER:
		{
			pCmdUI->Enable((pPeeperWnd && pPeeperWnd->GetState()));
		}
		break ;
	case ID_OPTION_PAUSE:
		{
			if(pPeeperWnd)
			{
				BOOL bPause = pPeeperWnd->IsPause();
				pCmdUI->SetCheck(!bPause);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_MOUSE_MOVE:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_MOVE);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_MOUSE_LBUTTON:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_LBUTTON);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_MOUSE_RBUTTON:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_RBUTTON);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_MOUSE_LDBLCLK:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_LDBLCLK);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_MOUSE_RDBLCLK:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_MOUSE_RDBLCLK);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_KEY:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_KEY);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_DIB:
		{
			if(pPeeperWnd)
			{
				BOOL bSet = pPeeperWnd->GetEnableFlag(PL_ENABLE_DIB);
				pCmdUI->SetCheck(bSet);
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_1BITS:
	case ID_OPTION_4BITS:
	case ID_OPTION_8BITS:
	case ID_OPTION_24BITS:
		{
			if(pPeeperWnd)
			{
				if((UINT)(pPeeperWnd->GetColorType()+ID_OPTION_1BITS) == pCmdUI->m_nID)
				{
					pCmdUI->SetRadio(TRUE);
				}
				else
				{
					pCmdUI->SetRadio(FALSE);
				}
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_OPTION_NOZIP:
	case ID_OPTION_LZ77:
	case ID_OPTION_LZW:
	case ID_OPTION_JPEG:
	case ID_OPTION_LZSS:
	case ID_OPTION_ARI:
		{
			if(pPeeperWnd)
			{
				if((UINT)(pPeeperWnd->GetZipType()+ID_OPTION_NOZIP) == pCmdUI->m_nID)
				{
					pCmdUI->SetRadio(TRUE);
				}
				else
				{
					pCmdUI->SetRadio(FALSE);
				}
			}
			else
			{
				pCmdUI->Enable(FALSE);
			}
		}
		break ;
	case ID_STATUS_CONN_INFO:
		{
			CString strInfo;
			if(pPeeperWnd)
			{
				strInfo = pPeeperWnd->GetClientInfo();
			}
			else
			{
				strInfo.LoadString(ID_STATUS_CONN_INFO);
			}
			m_wndStatusBar.SetPaneText(1, strInfo);
		}
		break ;
	case ID_STATUS_TIME:
		{
			CString strInfo;
			CString str;
			strInfo.LoadString(ID_STATUS_TIME);
			if(pPeeperWnd)
			{
				UINT nTime = pPeeperWnd->GetConnectTime();
				str.Format(strInfo, nTime/60, nTime%60);
			}
			else
			{
				str.Format(strInfo, 0, 0);
			}
			m_wndStatusBar.SetPaneText(2, str);
		}
		break ;
	default :
		break ;
	}
}

void CMainFrame::OnFullScreen()
{
	CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
	CChildFrame *pFrame = GetCurFrame();
	if(pPeeperWnd && pFrame)
	{
		SIZE sz = ::PL_GetScreenSize();
		CToolBarCtrl &bcCtrl = m_wndDibView.GetToolBarCtrl();
		BOOL bCheck = bcCtrl.IsButtonChecked(ID_TOOL_DIBVIEW_FULL);
		bcCtrl.CheckButton(ID_TOOL_DIBVIEW_FULL, !bCheck);
		if(!bCheck)
		{
			if(pFrame->IsZoomed())
			{
				m_nOldCmdShow = SW_SHOWMAXIMIZED;
			}
			else
			{
				m_nOldCmdShow = SW_SHOWNORMAL;
			}
			pFrame->ShowWindow(SW_SHOWMAXIMIZED);
			ShowControlBar(&m_wndDibView, TRUE, FALSE);
			FloatControlBar(&m_wndDibView, CPoint(sz.cx - 60, 10));
			RecalcLayout(); // must
			CRect rc;
			CRect rect;
			GetWindowRect(&m_rcOldRect);
			pPeeperWnd->GetWindowRect(&rc);
			rect.left = m_rcOldRect.left - rc.left - 2;
			rect.top = m_rcOldRect.top - rc.top - 2;
			rect.right = sz.cx + m_rcOldRect.right - rc.right + 2;
			rect.bottom = sz.cy + m_rcOldRect.bottom - rc.bottom + 2;

			MoveWindow(rect);
			m_bIsFullScreen = TRUE;
		}
		else
		{
			ShowControlBar(&m_wndDibView, FALSE, FALSE);
			pFrame->ShowWindow(m_nOldCmdShow);
			DockControlBar(&m_wndDibView);
			MoveWindow(m_rcOldRect);
			m_bIsFullScreen = FALSE;
		}
	}
}

void CMainFrame::OnExecCommand()
{
	CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
	if(pPeeperWnd)
	{
		char chData[1024];
		ZeroMemory(chData, 1024);
		m_wndCommand.GetDlgItemText(IDC_EDIT_COMMAND_INPUT, chData, 1024);
		CComboBox *pCombo = (CComboBox *)(m_wndCommand.GetDlgItem(IDC_COMBO_COMMAND_TYPE));
		if(pCombo)
		{
			int nCur = pCombo->GetCurSel();
			if(nCur >= 0)
			{
				int nType = pCombo->GetItemData(nCur);
				switch(nType)
				{
				case PL_MSG:
					{
						pPeeperWnd->T_SendMsg(chData, 0);
					}
					break ;
				case PL_FUNC_EXEC:
					{
						pPeeperWnd->T_RunCommand(chData);
					}
					break ;
				default :
					break ;
				}
			}
		}
	}
}

void CMainFrame::OnExecComputer()
{
	CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
	if(pPeeperWnd)
	{
		CComboBox *pCombo = (CComboBox *)(m_wndComputer.GetDlgItem(IDC_COMBO_COMPUTER_TYPE));
		if(pCombo)
		{
			int nCur = pCombo->GetCurSel();
			if(nCur >= 0)
			{
				int nType = pCombo->GetItemData(nCur);
				switch(nType)
				{
				case PL_FUNC_EXITWIN+0:
					{
						pPeeperWnd->T_ExitWindow(EWX_FORCE | EWX_LOGOFF);
					}
					break ;
				case PL_FUNC_EXITWIN+1:
					{
						pPeeperWnd->T_ExitWindow(EWX_FORCE | EWX_REBOOT);
					}
					break ;
				case PL_FUNC_EXITWIN+2:
					{
						pPeeperWnd->T_ExitWindow(EWX_FORCE | EWX_SHUTDOWN);
					}
					break ;
				case PL_FUNC_EXITWIN+3:
					{
						pPeeperWnd->T_LockDesktop(TRUE);
					}
					break ;
				case PL_FUNC_EXITWIN+4:
					{
						pPeeperWnd->T_LockDesktop(FALSE);
					}
					break ;
				default :
					break ;
				}
			}
		}
	}
}

void CMainFrame::OnExecFile()
{
	CPeeperWnd *pPeeperWnd = GetCurPeeperWnd();
	if(pPeeperWnd)
	{
		char chFile1[512];
		char chFile2[512];
		ZeroMemory(chFile1, 512);
		ZeroMemory(chFile2, 512);
		m_wndFile.GetDlgItemText(IDC_EDIT_FILE_SOURCE, chFile1, 512);
		m_wndFile.GetDlgItemText(IDC_EDIT_FILE_TARGET, chFile2, 512);
		CComboBox *pCombo = (CComboBox *)(m_wndFile.GetDlgItem(IDC_COMBO_FILE_TYPE));
		if(pCombo)
		{
			int nCur = pCombo->GetCurSel();
			if(nCur >= 0)
			{
				int nType = pCombo->GetItemData(nCur);
				switch(nType)
				{
				case PL_FUNC_FILE_COPY_S:
					{
						pPeeperWnd->T_CopyFileToRemote(chFile1, chFile2, NULL);
					}
					break ;
				case PL_FUNC_FILE_COPY_C:
					{
						pPeeperWnd->T_CopyFileFromRemote(chFile1, chFile2, NULL);
					}
					break ;
				case PL_FUNC_FILE_DELETE:
					{
						pPeeperWnd->T_DeleteFile(chFile1);
					}
					break ;
				case PL_FUNC_FILE_MOVE:
					{
						pPeeperWnd->T_MoveFile(chFile1, chFile2);
					}
					break ;
				default :
					break ;
				}
			}
		}
	}
}

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN)
	{
		if(pMsg->wParam == VK_RETURN)
		{
			CWnd *pFoucs = GetFocus();
			if(pFoucs == m_wndCommand.GetDlgItem(IDC_EDIT_COMMAND_INPUT) ||
				pFoucs == m_wndCommand.GetDlgItem(IDC_COMBO_COMMAND_TYPE))
			{
				OnExecCommand();
			}
			else if(pFoucs == m_wndComputer.GetDlgItem(IDC_COMBO_COMPUTER_TYPE))
			{
				OnExecComputer();
			}
			else if(pFoucs == m_wndFile.GetDlgItem(IDC_EDIT_FILE_SOURCE) ||
				pFoucs == m_wndFile.GetDlgItem(IDC_EDIT_FILE_TARGET) ||
				pFoucs == m_wndFile.GetDlgItem(IDC_COMBO_FILE_TYPE))
			{
				OnExecFile();
			}
		}
		else if(m_bIsFullScreen && (pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_F11))
		{
			OnFullScreen();
		}
		else if(!m_bIsFullScreen && pMsg->wParam == VK_F11)
		{
			OnFullScreen();
		}
	}
	return CMDIFrameWnd::PreTranslateMessage(pMsg);
}

void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI)
{
	lpMMI->ptMaxSize.x		= 3200;
	lpMMI->ptMaxSize.y		= 2400;
	lpMMI->ptMaxTrackSize.x = 3200;
	lpMMI->ptMaxTrackSize.y = 2400;

	CMDIFrameWnd::OnGetMinMaxInfo(lpMMI);
}

void CMainFrame::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	if(lpDrawItemStruct->CtlType == ODT_MENU)
	{
		m_hPeeperMenu.DrawItem(lpDrawItemStruct);
		return ;
	}
	CMDIFrameWnd::OnDrawItem(nIDCtl, lpDrawItemStruct);
}

void CMainFrame::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	if(lpMeasureItemStruct->CtlType == ODT_MENU)
	{
		m_hPeeperMenu.MeasureItem(lpMeasureItemStruct);
		return ;
	}
	CMDIFrameWnd::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}
