#ifndef __PEEPER_DOC_H__
#define __PEEPER_DOC_H__

class CPeeperClientDoc : public CDocument
{
	DECLARE_DYNCREATE(CPeeperClientDoc)
public:
	CPeeperClientDoc();
	virtual ~CPeeperClientDoc();

public:
	//{{AFX_VIRTUAL(CPeeperClientDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void OnCloseDocument();
	//}}AFX_VIRTUAL
public:
	UINT m_uPort;
	CString m_strIP;
	int m_nBits;
	UINT m_nSpeed;

protected:
	//{{AFX_MSG(CPeeperClientDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //__PEEPER_DOC_H__