#include "stdafx.h"
#include "PeeperClient.h"
#include "PeeperFrm.h"
#include "PeeperClientDoc.h"
#include "PeeperWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;//Ԥ���������������ص�ǰ������ļ��������бȽϳ��õļ���Ԥ����������
#endif

BEGIN_MESSAGE_MAP(CPeeperClientApp, CWinApp)
	//{{AFX_MSG_MAP(CPeeperClientApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

CPeeperClientApp::CPeeperClientApp()
{
}

CPeeperClientApp theApp;

BOOL CPeeperClientApp::InitInstance()
{
	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_PEEPERTYPE,
		RUNTIME_CLASS(CPeeperClientDoc),
		RUNTIME_CLASS(CChildFrame),
		RUNTIME_CLASS(CPeeperWnd)/*ʹ���Լ���Window*/);
	AddDocTemplate(pDocTemplate);

	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	pMainFrame->PeeperClientMenuAttach(pDocTemplate->m_hMenuShared);
	pMainFrame->PeeperMenuAttach(pMainFrame->m_hMenuDefault);

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;

	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	return TRUE;
}

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CPeeperClientApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetDlgItemText(IDC_EDIT_EMAIL, _T("dongfa@yeah.net"));
	CString strVer;
	GetDlgItemText(IDC_STATIC_VER, strVer);
	strVer += CPeeperWnd::GetClientVersion();
	SetDlgItemText(IDC_STATIC_VER, strVer);

	return TRUE;
}

CRegisterDlg::CRegisterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRegisterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRegisterDlg)
	//}}AFX_DATA_INIT
}

void CRegisterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegisterDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRegisterDlg, CDialog)
	//{{AFX_MSG_MAP(CRegisterDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CRegisterDlg::OnOK()
{
	GetDlgItemText(IDC_EDIT_USER, m_strUserName);
	GetDlgItemText(IDC_EDIT_CODE, m_strCode);
	CDialog::OnOK();
}

BOOL CRegisterDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CString strListen;
	strListen.LoadString(IDS_LISTEN);
	SetDlgItemText(IDC_EDIT_LISTEN, strListen);
	return TRUE;
}
