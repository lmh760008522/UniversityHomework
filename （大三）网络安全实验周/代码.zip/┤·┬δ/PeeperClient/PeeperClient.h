#ifndef __PEEPER_APP_H__
#define __PEEPER_APP_H__

#include "resource.h"

class CPeeperClientApp : public CWinApp
{
public:
	CPeeperClientApp();
	//{{AFX_VIRTUAL(CPeeperClientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CPeeperClientApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


class CRegisterDlg : public CDialog
{
public:
	CRegisterDlg(CWnd* pParent = NULL);

public:
	CString m_strUserName;
	CString m_strCode;
	//{{AFX_DATA(CRegisterDlg)
	enum { IDD = IDD_REGISTER };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CRegisterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	//}}AFX_VIRTUAL
protected:
	//{{AFX_MSG(CRegisterDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //__PEEPER_APP_H__
