//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PeeperClient.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DLGBAR_COMPUTER             103
#define IDP_SOCKETS_INIT_FAILED         104
#define IDD_DLGBAR_COMMAND              104
#define CG_ID_VIEW_DLGBAR               105
#define IDD_DLGBAR_FILE                 105
#define ID_STATUS_CONN_INFO             106
#define ID_STATUS_TIME                  107
#define IDD_DIALOG_SET                  108
#define IDD_REGISTER                    109
#define IDR_MAINFRAME                   128
#define IDR_PEEPERTYPE                  129
#define IDR_TOOLBAR_DIBVIEW             139
#define IDB_MAINCLIENT_BK               145
#define IDB_BITMAP_MENU_BK              147
#define IDC_EDIT_IP                     1000
#define IDC_EDIT_COMMAND_INPUT          1000
#define IDC_EDIT_PORT                   1001
#define IDC_COMBO_COMMAND_TYPE          1001
#define IDC_EDIT_BITS                   1002
#define IDC_BTN_COMMAND_EXEC            1002
#define IDC_EDIT_SPEED                  1003
#define IDC_EDIT_FILE_SOURCE            1003
#define IDC_EDIT_FILE_TARGET            1004
#define IDC_BTN_FILE_SOURCE             1005
#define IDC_BTN_FILE_TARGET             1006
#define IDC_BTN_FILE_EXEC               1007
#define IDC_COMBO_FILE_TYPE             1008
#define IDC_EDIT_EMAIL                  1009
#define IDC_COMBO_COMPUTER_TYPE         1009
#define IDC_BTN_COMPUTER_EXEC           1010
#define IDC_EDIT_USER                   1011
#define IDC_EDIT_CODE                   1012
#define IDC_EDIT_LISTEN                 1013
#define IDC_STATIC_VER                  1014
#define ID_HELP_HELP                    32783
#define ID_HELP_REGISTER                32784
#define ID_FILE_CLOSESERVER             32787
#define ID_VIEW_SEND                    32788
#define ID_FILE_MANAGE                  32789
#define ID_VIEW_COMPUTER                32790
#define ID_OPTION_MOUSE_MOVE            32794
#define ID_OPTION_MOUSE_LBUTTON         32795
#define ID_OPTION_MOUSE_RBUTTON         32796
#define ID_OPTION_KEY                   32797
#define ID_OPTION_MOUSE_LDBLCLK         32798
#define ID_OPTION_MOUSE_RDBLCLK         32799
#define ID_OPTION_DIB                   32800
#define ID_TOOL_DIBVIEW_FULL            32808
#define ID_TOOL_PROPERTY                32809
#define ID_OPTION_ENABLEALL             32811
#define ID_OPTION_1BITS                 32812
#define ID_OPTION_4BITS                 32813
#define ID_OPTION_8BITS                 32814
#define ID_OPTION_24BITS                32815
#define ID_OPTION_NOZIP                 32817
#define ID_OPTION_LZ77                  32818
#define ID_OPTION_LZW                   32819
#define ID_OPTION_JPEG                  32820
#define ID_OPTION_LZSS                  32821
#define ID_OPTION_ARI                   32822
#define ID_OPTION_PAUSE                 32826
#define IDS_LISTEN                      59394

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32833
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
