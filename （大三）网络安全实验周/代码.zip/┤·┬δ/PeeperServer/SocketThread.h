//������
#ifndef __PEEPER_SOCKETTHREAD_H__
#define __PEEPER_SOCKETTHREAD_H__

#include "../PeeperLib.h"

class CSocketThread : public CWinThread
{
public:
	CSocketThread(UINT uPort = PL_PEEPER_PORT);
	virtual ~CSocketThread();

protected:
	SOCKET m_sckServer;
	SOCKET m_sckClient[2];

	UINT m_uPort;
	int m_nBits;

public:
	int DoReceive(BYTE *chData, int nLen);
	BOOL ExitServer();
	BOOL CreateServer();

public:
	virtual int Run();
	virtual BOOL InitInstance()
	{
		return TRUE;
	}
	virtual int ExitInstance()
	{
		return CWinThread::ExitInstance();
	}
};

#endif //__PEEPER_SOCKETTHREAD_H__
