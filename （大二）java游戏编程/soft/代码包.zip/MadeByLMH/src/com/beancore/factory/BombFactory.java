package com.beancore.factory;

import com.beancore.config.ImageConstants;
import com.beancore.entity.Bomb2;
import com.beancore.entity.EnemyPlane2;

public class BombFactory {
		    public static final Bomb2 createBomb(EnemyPlane2 enemyPlane) {
		    	
				int planePosX = enemyPlane.getPosX();
				int planePosY = enemyPlane.getPosY();

				int bombPosX = planePosX + enemyPlane.getWidth() / 2 - ImageConstants.BOMB_WIDTH / 2;
				int bombPosY = planePosY + ImageConstants.BOMB_HEIGHT;

				Bomb2 b=new Bomb2(enemyPlane.getGamePlayingPanel());
				b.setPosX(bombPosX);
				b.setPosY(bombPosY);
				return b;
			    }
}
