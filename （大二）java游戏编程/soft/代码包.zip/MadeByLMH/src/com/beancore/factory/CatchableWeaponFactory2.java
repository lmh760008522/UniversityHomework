package com.beancore.factory;

import java.util.Random;

import com.beancore.config.CatchableWeaponType;
import com.beancore.config.Config;
import com.beancore.config.ImageConstants;
import com.beancore.entity.CatchableWeapon2;
import com.beancore.entity.DoubleLaser2;
import com.beancore.ui.GamePlayingPanel2;
import com.beancore.util.Images;

public class CatchableWeaponFactory2 {
	 public static final Random rand = new Random();

	    public static CatchableWeapon2 createCatchableWeapon(GamePlayingPanel2 gamePlayingPanel, CatchableWeaponType weaponType) {
	    CatchableWeapon2 weapon = null;
		switch (weaponType) {
		case BOMB:
		    break;
		case DOUBLE_LASER:
		    weapon = new DoubleLaser2(gamePlayingPanel, weaponType);
		    weapon.setWidth(ImageConstants.DOUBLE_LASER_WIDTH);
		    weapon.setHeight(ImageConstants.DOUBLE_LASER_HEIGHT);
		    weapon.setWeaponImage(Images.DOUBLE_LASER_IMG);
		    weapon.setSpeed(Config.POP_WEAPON_MOVE_SPEED);
		    int posX = rand.nextInt(gamePlayingPanel.getWidth() - weapon.getWidth());
			int posY = 0;
			weapon.setPosX(posX);
			weapon.setPosY(posY);
			return weapon;
		    
		}

		return null;

		
	    }
}
