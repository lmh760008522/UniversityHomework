package com.beancore.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.beancore.ui.GameButton;
import com.beancore.ui.MainFrame;

import com.beancore.config.Config;
import com.beancore.util.Images;

public class popupStartGamePanel extends JPanel{
	private static final long serialVersionUID = 1L;
    private JLabel logoLabel;
    private GameButton FJ;
    private GameButton PT;
    private GameButton back;
    
    public final static String START_FJ_BUTTON = "START_FJ_BUTTON";
    public final static String START_PT_BUTTON = "START_PT_BUTTON";
    public final static String BACK = "BACK";
    
    public popupStartGamePanel(MainFrame mainFrame) {
		this.initComponents(mainFrame);
	}

	private void initComponents(MainFrame mainFrame) {
	this.logoLabel = new JLabel();
	this.logoLabel.setIcon(new ImageIcon(Images.MY_PLANE_IMG));

	
	//���ð�ť
	this.FJ = new GameButton("�ɻ���ɻ�");
	this.FJ.addActionListener(mainFrame);
	this.FJ.setActionCommand(START_FJ_BUTTON);
	this.FJ.setOpaque(false);

	this.PT = new GameButton("��̨��ɻ�");
	this.PT.addActionListener(mainFrame);
	this.PT.setActionCommand(START_PT_BUTTON);
	this.PT.setOpaque(false);
	
	this.back = new GameButton("����");
	this.back.addActionListener(mainFrame);
	this.back.setActionCommand(BACK);
	this.back.setOpaque(false);
	
	JPanel logoPanel = new JPanel();
	logoPanel.setOpaque(false);
	logoPanel.add(logoLabel);

	GridLayout gridLayout = new GridLayout(4, 1, 0, 10);
	JPanel buttonPanel = new JPanel();
	buttonPanel.setOpaque(false);
	buttonPanel.setLayout(gridLayout);

	//���Ӱ�ť
	buttonPanel.add(FJ);
	buttonPanel.add(PT);
	buttonPanel.add(back);

	Dimension d = new Dimension(Config.POP_UP_MENU_PANEL_WIDTH, Config.POP_UP_MENU_PANEL_HEIGHT);
	buttonPanel.setSize(d);
	buttonPanel.setPreferredSize(d);

	BorderLayout mainLayout = new BorderLayout();
	mainLayout.setVgap(25);
	JPanel mainPanel = new JPanel();
	mainPanel.setOpaque(false);
	mainPanel.setLayout(mainLayout);
	mainPanel.add(logoPanel, BorderLayout.NORTH);
	mainPanel.add(buttonPanel, BorderLayout.CENTER);

	this.setOpaque(false);
	this.add(mainPanel);
    }

}
