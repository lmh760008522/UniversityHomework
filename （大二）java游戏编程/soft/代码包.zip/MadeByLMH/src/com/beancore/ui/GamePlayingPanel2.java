package com.beancore.ui;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JPanel;

import com.beancore.ui.GamePlayingPanel2;

import com.beancore.config.CatchableWeaponType;
import com.beancore.config.Config;
import com.beancore.config.EnemyPlaneType;
import com.beancore.config.ImageConstants;
import com.beancore.entity.Bomb2;
import com.beancore.entity.Bullet2;
import com.beancore.entity.CatchableWeapon2;
import com.beancore.entity.EnemyPlane2;
import com.beancore.entity.MyPlane2;
import com.beancore.factory.CatchableWeaponFactory2;
import com.beancore.factory.EnemyPlaneFactory2;
import com.beancore.listener.BombListener;
import com.beancore.listener.BulletListener2;
import com.beancore.listener.CatchableWeaponListener2;
import com.beancore.listener.EnemyPlaneListener2;
import com.beancore.util.Images;
import com.beancore.util.SoundPlayer;

public class GamePlayingPanel2 extends JPanel implements MouseListener, MouseMotionListener, BulletListener2,BombListener,
CatchableWeaponListener2, ImageObserver, EnemyPlaneListener2 {
private static final long serialVersionUID = 1L;//���к�
private static int ANIMATION_STEP_1 = 1;
private static int ANIMATION_STEP_2 = 2;

private volatile List<Bullet2> bullets;
private volatile List<Bomb2> bombs;
private volatile List<MyPlane2> myPlanes;
private volatile List<EnemyPlane2> enemyPlanes;
private int score;//����
private MyPlane2 myPlane;

private CatchableWeapon2 popDoubleLaser;//˫�ӵ�

private Thread paintThread;

private int remainTimeToPopSmallPlane;
private int remainTimeToPopBigPlane;
private int remainTimeToPopBossPlane;

private int remainTimeToPopDoubleLaser;

private int remainTimeDoubleLaserRunOut;

private int doubleLaserAnimationStep;

//���ֲ���
private SoundPlayer smallPlaneKilledSoundPlayer;
private SoundPlayer bigPlaneKilledSoundPlayer;
private SoundPlayer bossPlaneKilledSoundPlayer;

private SoundPlayer bossPlaneFlyingSoundPlayer;
private SoundPlayer popWeaponSoundPlayer;
private SoundPlayer useBombSoundPlayer;
private SoundPlayer fireBulletSoundPlayer;

private SoundPlayer getDoubleLaserSoundPlayer;

private SoundPlayer gameMusicSoundPlayer;
private SoundPlayer gameOverSoundPlayer;

private boolean flag=true;//�ж��Ƿ���ͣ�����



//���캯��
public GamePlayingPanel2() throws LineUnavailableException, UnsupportedAudioFileException, IOException {
this.initSoundPlayer();//��ʼ������
this.initComponents(); //��ʼ������
}


//��ʼ�����ֺ���
private void initSoundPlayer() throws LineUnavailableException, UnsupportedAudioFileException, IOException {
	smallPlaneKilledSoundPlayer = new SoundPlayer(Config.SMALL_PLANE_KILLED_AUDIO);
	bigPlaneKilledSoundPlayer = new SoundPlayer(Config.BIG_PLANE_KILLED_AUDIO);
	bossPlaneKilledSoundPlayer = new SoundPlayer(Config.BOSS_PLANE_KILLED_AUDIO);

	bossPlaneFlyingSoundPlayer = new SoundPlayer(Config.BOSS_PLANE_FLYING_AUDIO);
	popWeaponSoundPlayer = new SoundPlayer(Config.POP_WEAPON_AUDIO);
	useBombSoundPlayer = new SoundPlayer(Config.USER_BOMB_AUDIO);
	fireBulletSoundPlayer = new SoundPlayer(Config.FIRE_BULLET_AUDIO);

	getDoubleLaserSoundPlayer = new SoundPlayer(Config.GET_DOUBLE_LASER_AUDIO);
	gameMusicSoundPlayer = new SoundPlayer(Config.GAME_MUSIC_AUDIO);
	gameOverSoundPlayer = new SoundPlayer(Config.GAME_OVER_AUDIO);
}


//��ʼ�����溯��
private void initComponents() {
	this.addMouseMotionListener(this);
	this.addMouseListener(this);
	this.setSize(Config.MAIN_FRAME_WIDTH, Config.MAIN_FRAME_HEIGHT);
	this.setDoubleBuffered(true);//���û������
	this.setOpaque(false);
   }

//�ӵ�λ�ñ仯
public void onBulletLocationChanged(Bullet2 b) {
if (b != null) {
   b.setPosY(b.getPosY() - b.getSpeed());//ʹ�ӵ���ͣ���ƶ�
   if (b.getPosY() <= 0) {//�ӵ��ɳ���Ļ
	synchronized (this.bullets) {
	    this.bullets.remove(b);
	}
 }
   EnemyPlane2 enemyPlane = b.hitEnemyPlanes();                           ////////////////////////
   if (enemyPlane != null) {
	enemyPlane.drawFighting(this.getComponentGraphics(this.getGraphics())); 
	if (enemyPlane.isKilled()) {//����
		//���ݴ򵽵о��ɻ��Ĳ�ͬ���Ų�ͬ������
	    switch (enemyPlane.getEnemyType()) {
	    case SMALL_ENEMY_PLANE:
		this.smallPlaneKilledSoundPlayer.play();
		break;
	    case BIG_ENEMY_PLANE:
		this.bigPlaneKilledSoundPlayer.play();
		break;
	    case BOSS_ENEMY_PLANE:
		this.bossPlaneFlyingSoundPlayer.stop();
		this.bossPlaneKilledSoundPlayer.play();
		break;
	    }
	    
	    //�ӷ�
	    synchronized (this) {
		this.score += enemyPlane.getKilledScore();
	    }
	    //�Ƴ��о��ɻ�
	    synchronized (this.enemyPlanes) {
		this.enemyPlanes.remove(enemyPlane);
	    }
	    //�Ƴ��ӵ�
	    synchronized (this.bullets) {
		this.bullets.remove(b);
	    }
	    enemyPlane.drawKilled(this.getComponentGraphics(this.getGraphics()));
	}
 }
}
}

//ը���ƶ�
public void onBombLocationChanged(Bomb2 b) {
if (b != null) {
   b.setPosY(b.getPosY() + b.getSpeed());//ʹը����ͣ���ƶ�
   if (b.getPosY() >= 700) {//ը���ɳ���Ļ
	synchronized (this.bombs) {
	    this.bombs.remove(b);
	  }
   }
   MyPlane2 myPlane = b.hitMyPlanes();                    
   if (myPlane != null) {
	if (myPlane.getHittedCount()<=3) {//����
		this.useBombSoundPlayer.play();
	    //�Ƴ�ը��
	    synchronized (this.bullets) {
		this.bombs.remove(b);
	    }
	   
	}
	else{
		 synchronized (myPlane) {
				if (myPlane.isAlive()) {
				    this.stopGame();
				}
			    }	
	}
 }
}
}


//�о��ɻ�λ�ñ仯
public void onEnemyPlaneLocationChanged(EnemyPlane2 p) {
if (p != null && !p.isKilled()) {
   p.setPosX(p.getPosX() + p.getSpeed());//ʹ�о��ɻ��ƶ�
   if (p.getPosX() >= this.getWidth()) {//���ɳ���Ļ
	if (p.getEnemyType().equals(EnemyPlaneType.BOSS_ENEMY_PLANE)) {
	    this.bossPlaneFlyingSoundPlayer.stop();
	}
	synchronized (this.enemyPlanes) {
	    enemyPlanes.remove(p);
	}
   } 
}
}

//������������
public void onCatchableWeaponLocationChanged(CatchableWeapon2 weapon) {
if (weapon != null) {
   synchronized (weapon) {
	int posY = weapon.getPosY();
	if (weapon.isUseAnimation()) {
	    switch (weapon.getWeaponType()) {
	    case BOMB:
		break;
	    case DOUBLE_LASER:
		if (this.doubleLaserAnimationStep == ANIMATION_STEP_1) {
		    posY += Config.POP_WEAPON_ANIMATION_MOVE_FORWARD_SPEED;
		    this.doubleLaserAnimationStep++;
		} else if (this.doubleLaserAnimationStep == ANIMATION_STEP_2) {
		    posY -= Config.POP_WEAPON_ANIMATION_MOV_BACK_SPEED;
		    this.doubleLaserAnimationStep = 0;
		    weapon.setUseAnimation(false);
		    weapon.setUseAnimationDone(true);
		}
		break;
	    }
	} else {
	    posY += weapon.getSpeed();
	}

	weapon.setPosY(posY);

	if (!weapon.isUseAnimationDone() && weapon.getPosY() >= this.getHeight() / 5) {
	    weapon.setUseAnimation(true);
	    switch (weapon.getWeaponType()) {
	    case BOMB:
		break;
	    case DOUBLE_LASER:
		if (this.doubleLaserAnimationStep == 0) {
		    this.doubleLaserAnimationStep++;
		}
		break;
	    }
	}

	if (weapon.getPosY() >= this.getHeight()) {
	    weapon.setWeaponDisappear(true);
	} else {
	    if (weapon.getRectangle().intersects(myPlane.getRectange())) {
		switch (weapon.getWeaponType()) {
		case BOMB:
		    break;
		case DOUBLE_LASER:
		    myPlane.setHitDoubleLaser(true);
		    this.getDoubleLaserSoundPlayer.play();
		    break;
		}
		weapon.setWeaponDisappear(true);
	    }
	}
   }
}
}

//��ӡ��������
private void drawScore(Graphics g) {
	Graphics2D g2d = (Graphics2D) g;
	List<Integer> intList = new ArrayList<Integer>();
	int scoreCopy = this.score;//��÷���
	int quotient = 0;
	
	//����������λ�������ַֿ����б�����
	while ((quotient = scoreCopy / 10) != 0) {
	  intList.add(scoreCopy % 10);
	  scoreCopy = quotient;
	}
	intList.add(scoreCopy % 10);
	
	//���Ʒ���
	int posX = Config.SCORE_IMG_POS_X;
	int posY = Config.SCORE_IMG_POS_Y;
	int size = intList.size();
	for (int i = size - 1; i >= 0; i--) {
	  switch (intList.get(i)) {
	  case Config.NUMBER_0:
		g2d.drawImage(Images.NUMBER_0_IMG, posX, posY, ImageConstants.NUMBER_0_WIDTH,
			ImageConstants.NUMBER_0_HEIGHT, this);
		posX += ImageConstants.NUMBER_0_WIDTH;
		break;
	  case Config.NUMBER_1:
		g2d.drawImage(Images.NUMBER_1_IMG, posX, posY, ImageConstants.NUMBER_1_WIDTH,
			ImageConstants.NUMBER_1_HEIGHT, this);
		posX += ImageConstants.NUMBER_1_WIDTH;
		break;
	  case Config.NUMBER_2:
		g2d.drawImage(Images.NUMBER_2_IMG, posX, posY, ImageConstants.NUMBER_2_WIDTH,
			ImageConstants.NUMBER_2_HEIGHT, this);
		posX += ImageConstants.NUMBER_2_WIDTH;
		break;
	  case Config.NUMBER_3:
		g2d.drawImage(Images.NUMBER_3_IMG, posX, posY, ImageConstants.NUMBER_3_WIDTH,
			ImageConstants.NUMBER_3_HEIGHT, this);
		posX += ImageConstants.NUMBER_3_WIDTH;
		break;
	  case Config.NUMBER_4:
		g2d.drawImage(Images.NUMBER_4_IMG, posX, posY, ImageConstants.NUMBER_4_WIDTH,
			ImageConstants.NUMBER_4_HEIGHT, this);
		posX += ImageConstants.NUMBER_4_WIDTH;
		break;
	  case Config.NUMBER_5:
		g2d.drawImage(Images.NUMBER_5_IMG, posX, posY, ImageConstants.NUMBER_5_WIDTH,
			ImageConstants.NUMBER_5_HEIGHT, this);
		posX += ImageConstants.NUMBER_5_WIDTH;
		break;
	  case Config.NUMBER_6:
		g2d.drawImage(Images.NUMBER_6_IMG, posX, posY, ImageConstants.NUMBER_6_WIDTH,
			ImageConstants.NUMBER_6_HEIGHT, this);
		posX += ImageConstants.NUMBER_6_WIDTH;
		break;
	  case Config.NUMBER_7:
		g2d.drawImage(Images.NUMBER_7_IMG, posX, posY, ImageConstants.NUMBER_7_WIDTH,
			ImageConstants.NUMBER_7_HEIGHT, this);
		posX += ImageConstants.NUMBER_7_WIDTH;
		break;
	  case Config.NUMBER_8:
		g2d.drawImage(Images.NUMBER_8_IMG, posX, posY, ImageConstants.NUMBER_8_WIDTH,
			ImageConstants.NUMBER_8_HEIGHT, this);
		posX += ImageConstants.NUMBER_8_WIDTH;
		break;
	  case Config.NUMBER_9:
		g2d.drawImage(Images.NUMBER_9_IMG, posX, posY, ImageConstants.NUMBER_9_WIDTH,
			ImageConstants.NUMBER_9_HEIGHT, this);
		posX += ImageConstants.NUMBER_9_WIDTH;
		break;
	  }
	}
}



//��ӡ��������
private void drawLifeLeft(Graphics g) {
Graphics2D g2d = (Graphics2D) g;
//List<Integer> intList = new ArrayList<Integer>();
int lifeCopy = 3-this.myPlane.getHittedCount();//�������
for (int i=0;i<lifeCopy;i++){
	g2d.drawImage(Images.SCORE_IMG,i* ImageConstants.SCORE_IMG_WIDTH,Config.SCORE_IMG_POS_Y+ ImageConstants.SCORE_IMG_HEIGHT, ImageConstants.SCORE_IMG_WIDTH, ImageConstants.SCORE_IMG_HEIGHT,
		this);
}
}


   //�̺߳���
class PaintThread implements Runnable {
	public void run() {
	    while (myPlane.isAlive()) {//�����ţ���ͣ�ķ��ӵ�
		for (int i = 0; i < bullets.size(); i++) {
		    Bullet2 b = bullets.get(i);
		    onBulletLocationChanged(b);
		}
		
		for (int i = 0; i < enemyPlanes.size(); i++) {
		    EnemyPlane2 enemyPlane = enemyPlanes.get(i);
		    onEnemyPlaneLocationChanged(enemyPlane);
		}
		
		for (int i = 0; i < bombs.size(); i++) {
		    Bomb2 b = bombs.get(i);
		    onBombLocationChanged(b);
		}
		
		if (remainTimeToPopSmallPlane > 0) {//ʹС�ɻ����ӵ�Խ��Խ��
		    remainTimeToPopSmallPlane -=(Config.GAME_PANEL_REPAINT_INTERVAL);
		} else {
		    //����һ��С�ɻ�
		    EnemyPlane2 smallPlane = EnemyPlaneFactory2.createEnemyPlane(GamePlayingPanel2.this,
			    EnemyPlaneType.SMALL_ENEMY_PLANE);
		    synchronized (GamePlayingPanel2.this.enemyPlanes) {
			enemyPlanes.add(smallPlane);
		    }
		    remainTimeToPopSmallPlane = Config.POP_SMALL_ENEMY_PLANE_INTERVAL;
		}
		
		
		if (remainTimeToPopBigPlane > 0) {
		    remainTimeToPopBigPlane -= Config.GAME_PANEL_REPAINT_INTERVAL+1000;//////////////////
		} else {
		    EnemyPlane2 bigPlane = EnemyPlaneFactory2.createEnemyPlane(GamePlayingPanel2.this,
			    EnemyPlaneType.BIG_ENEMY_PLANE);
		    synchronized (GamePlayingPanel2.this.enemyPlanes) {
			enemyPlanes.add(bigPlane);
		    }
		    remainTimeToPopBigPlane = Config.POP_BIG_ENEMY_PLANE_INTERVAL;
		}

		if (remainTimeToPopBossPlane > 0) {
		    remainTimeToPopBossPlane -= Config.GAME_PANEL_REPAINT_INTERVAL;
		} else {
		    EnemyPlane2 bossPlane = EnemyPlaneFactory2.createEnemyPlane(GamePlayingPanel2.this,
			    EnemyPlaneType.BOSS_ENEMY_PLANE);
		    synchronized (GamePlayingPanel2.this.enemyPlanes) {
			enemyPlanes.add(bossPlane);
		    }
		    remainTimeToPopBossPlane = Config.POP_BOSS_ENEMY_PLANE_INTERVAL;
		    bossPlaneFlyingSoundPlayer.loop();
		}
		
		if (remainTimeToPopDoubleLaser > 0) {
		    remainTimeToPopDoubleLaser -= Config.GAME_PANEL_REPAINT_INTERVAL;
		} else {
		    popDoubleLaser = CatchableWeaponFactory2.createCatchableWeapon(GamePlayingPanel2.this,
			    CatchableWeaponType.DOUBLE_LASER);
		    remainTimeToPopDoubleLaser = Config.POP_DOUBLE_LASER_INTERVAL;
		    popWeaponSoundPlayer.play();
		}

		if (popDoubleLaser != null) {
		    onCatchableWeaponLocationChanged(popDoubleLaser);
		}

		
		if (remainTimeDoubleLaserRunOut > 0) {
		    remainTimeDoubleLaserRunOut -= Config.GAME_PANEL_REPAINT_INTERVAL;
		} else {
		    myPlane.setHitDoubleLaser(false);
		    popDoubleLaser = null;
		    remainTimeDoubleLaserRunOut = Config.DOUBLE_LASER_LAST_TIME;
		}

		if (popDoubleLaser != null && popDoubleLaser.isWeaponDisappear()) {
		    popDoubleLaser = null;
		}
		try {
			if(flag){
				GamePlayingPanel2.this.repaint();
				Thread.sleep(Config.GAME_PANEL_REPAINT_INTERVAL);//������̬Ч��
			}
		} catch (InterruptedException e) {

		}
	    }
	}
}

   protected void paintComponent(Graphics g) {
   	super.paintComponent(g);
   	drawScore(g);
   	drawLifeLeft(g);
   	myPlane.draw(g);
   	for (int i = 0; i < this.enemyPlanes.size(); i++) {
   	    EnemyPlane2 enemyPlane = this.enemyPlanes.get(i);
   	    enemyPlane.draw(g);
   	}
   	
   	for (int i = 0; i < this.bullets.size(); i++) {
   	    Bullet2 b = this.bullets.get(i);
   	    b.draw(g);
   	}
   	
   	for (int i = 0; i < this.bombs.size(); i++) {
   	    Bomb2 b = this.bombs.get(i);
   	    b.draw(g);
   	}
   	
   	if (this.popDoubleLaser != null && !this.popDoubleLaser.isWeaponDisappear()) {
   	    this.popDoubleLaser.draw(g);
   	}
       }
 

 //��ʼ��Ϸ����
   public void startGame() {
	this.score = 0;
	this.doubleLaserAnimationStep=0;
	
	this.remainTimeToPopSmallPlane = Config.POP_SMALL_ENEMY_PLANE_INTERVAL;
	this.remainTimeToPopBigPlane = Config.POP_BIG_ENEMY_PLANE_INTERVAL;
	this.remainTimeToPopBossPlane = Config.POP_BOSS_ENEMY_PLANE_INTERVAL;

	this.remainTimeToPopDoubleLaser = Config.POP_DOUBLE_LASER_INTERVAL;
	this.remainTimeDoubleLaserRunOut = Config.DOUBLE_LASER_LAST_TIME;
	this.bullets = new LinkedList<Bullet2>();
	this.bombs = new LinkedList<Bomb2>();
	this.enemyPlanes = new LinkedList<EnemyPlane2>();
	this.myPlane = new MyPlane2(this);
	this.myPlane.setAlive(true);
	this.myPlane.setPosX((Config.MAIN_FRAME_WIDTH - ImageConstants.MY_PLANE_WIDTH) / 2);
	this.myPlane.setPosY(Config.MAIN_FRAME_HEIGHT - ImageConstants.MY_PLANE_HEIGHT);
	this.gameMusicSoundPlayer.loop();
	this.fireBulletSoundPlayer.loop();
	this.paintThread = new Thread(new PaintThread());
	this.paintThread.start();
   }
     
   //��Ϸ��������
   public void stopGame() {
	this.myPlane.setAlive(false);
	this.gameMusicSoundPlayer.stop();
	this.fireBulletSoundPlayer.stop();
	this.bossPlaneFlyingSoundPlayer.stop();
	this.gameOverSoundPlayer.play();
   }

   //ʵ����
   public void mouseDragged(MouseEvent e) {
   }
   public void mouseMoved(MouseEvent e) {//�ɻ���������ƶ�
	if (this.myPlane != null && this.myPlane.isAlive()) {
	    myPlane.mouseMoved(e);
	    this.repaint();
	}
   }
   public List<Bullet2> getBullets() {
	return bullets;
   }
  
   public void setBullets(List<Bullet2> bullets) {
	this.bullets = bullets;
   }
   
   public List<Bomb2> getBombs() {
   	return bombs;
       }
      
       public void setBomb(List<Bomb2> bombs) {
   	this.bombs = bombs;
       }
   

 public List<EnemyPlane2> getEnemyPlanes() {
	return enemyPlanes;
	}
 
 
 public List<MyPlane2> getMyPlanes() {
		
		return myPlanes;
		}
 
 public void setEnemyPlanes(List<EnemyPlane2> enemyplane) {
	this.enemyPlanes = enemyplane;
  }
 
   public MyPlane2 getMyPlane() {
	return myPlane;
   }

   public int getScore() {
	return score;
   }

   public void mouseClicked(MouseEvent e) {
   	if (this.myPlane.isAlive() && this.myPlane.getHoldBombCount() > 0) {
   		if(flag==false){
				 flag=true;
			 }else{
				 flag=false;
			 }
   	}
       }
   public void mousePressed(MouseEvent e) {
   }

   public void mouseReleased(MouseEvent e) {
   }

   public void mouseEntered(MouseEvent e) {
   }

   public void mouseExited(MouseEvent e) {
   }



	
}