package com.beancore.config;

public enum BulletType {
    YELLOW_BULLET, BLUE_BULLET
}
