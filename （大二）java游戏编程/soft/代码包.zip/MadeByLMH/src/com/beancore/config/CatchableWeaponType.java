package com.beancore.config;

public enum CatchableWeaponType {
    BOMB, DOUBLE_LASER
}
