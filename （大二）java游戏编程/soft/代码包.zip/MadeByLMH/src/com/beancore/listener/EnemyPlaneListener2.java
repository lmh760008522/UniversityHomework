package com.beancore.listener;

import com.beancore.entity.EnemyPlane2;

public interface EnemyPlaneListener2 {
    void onEnemyPlaneLocationChanged(EnemyPlane2 p);

}
