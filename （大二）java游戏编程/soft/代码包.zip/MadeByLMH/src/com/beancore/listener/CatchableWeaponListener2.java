package com.beancore.listener;

import com.beancore.entity.CatchableWeapon2;

public interface CatchableWeaponListener2 {
	public void onCatchableWeaponLocationChanged(CatchableWeapon2 weapon);
}
