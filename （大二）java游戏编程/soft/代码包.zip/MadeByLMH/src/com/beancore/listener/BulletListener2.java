package com.beancore.listener;

import com.beancore.entity.Bullet2;

public interface BulletListener2 {
	 void onBulletLocationChanged(Bullet2 b);

}
