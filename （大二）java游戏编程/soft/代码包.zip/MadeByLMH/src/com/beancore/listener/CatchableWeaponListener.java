package com.beancore.listener;

import com.beancore.entity.CatchableWeapon;

public interface CatchableWeaponListener {
    public void onCatchableWeaponLocationChanged(CatchableWeapon weapon);
}
