package com.beancore.listener;

import com.beancore.entity.EnemyPlane;

public interface EnemyPlaneListener {
    void onEnemyPlaneLocationChanged(EnemyPlane p);

}
