package com.beancore.listener;

import com.beancore.entity.Bomb2;

public interface BombListener {
	void onBombLocationChanged(Bomb2 p);
}
