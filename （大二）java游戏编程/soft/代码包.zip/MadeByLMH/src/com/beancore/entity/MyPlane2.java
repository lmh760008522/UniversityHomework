package com.beancore.entity;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.LinkedList;
import java.util.List;

import com.beancore.config.BulletType;
import com.beancore.config.Config;
import com.beancore.config.ImageConstants;
import com.beancore.factory.BulletFactory2;
import com.beancore.ui.GamePlayingPanel2;
import com.beancore.util.Images;

public class MyPlane2{
	//��ǰ����
    private int posX;
    private int posY;
    private int width;
    private int height;
    private Image planeImage;
    private Image planeFlyingImage;
    private boolean isAlive;
    private boolean hitDoubleLaser;
    private List<Bomb2> holdBombList;
    private BulletType bulletType;
    private GamePlayingPanel2 playingPanel2;
    private boolean flip;
    
    private int hittedCount=0;
    
    
   
    public MyPlane2(GamePlayingPanel2 gamePlayingPanel2){
	this.isAlive = true;
	this.flip = true;
	this.playingPanel2 = gamePlayingPanel2;
	this.width = ImageConstants.MY_PLANE_WIDTH;
	this.height = ImageConstants.MY_PLANE_HEIGHT;
	this.planeImage = Images.MY_PLANE_IMG;
	this.planeFlyingImage = Images.MY_PLANE_FLYING_IMG;
	this.holdBombList= new LinkedList<Bomb2>();
	new Thread(new LauchBulletThread()).start();
    }
    
    public Rectangle getRectange() {
	int fix = width / 3;
	return new Rectangle(posX + fix, posY, width / 3, height);
    }

    public void draw(Graphics g) {
	Graphics2D g2d = (Graphics2D) g;
	if (flip) {
	    g2d.drawImage(planeImage, posX, posY, width, height, playingPanel2);
	} else {
	    g2d.drawImage(planeFlyingImage, posX, posY, width, height, playingPanel2);
	}
	flip = !flip;
    }

    public void mouseMoved(MouseEvent e) {
	int x = e.getX();
	posX = x - width / 2;
	posY =Config.MAIN_FRAME_HEIGHT-100;//��ֱλ�ò���
    }

    public void lauchBullet() {
	if (isAlive) {
	    if (hitDoubleLaser) {
		Bullet2 bullets[] = BulletFactory2.createBlueBullet(this);
		
		for (Bullet2 bullet : bullets) {
		    bullet.addBulletListener(this.playingPanel2);
		    synchronized (this.playingPanel2.getBullets()) {
			this.playingPanel2.getBullets().add(bullet);
		    }
		}
	    } else {
		Bullet2 bullet = BulletFactory2.createYellowBullet(this);
		bullet.addBulletListener(this.playingPanel2);
		synchronized (this.playingPanel2.getBullets()) {
		    this.playingPanel2.getBullets().add(bullet);
		}
	    }
	}
    }

    class LauchBulletThread implements Runnable {
	public void run() {
	    while (isAlive) {
		try {
		    Thread.sleep(Config.BULLET_FIRE_INTERVAL);
		} catch (InterruptedException e) {

		}
		lauchBullet();
	    }
	}
    }

    public int getHoldBombCount() {
	return this.holdBombList.size();
    }

    public int getPosX() {
	return posX;
    }

    public void setPosX(int posX) {
	this.posX = posX;
    }

    public int getPosY() {
	return posY;
    }

    public void setPosY(int posY) {
	this.posY = posY;
    }

    public int getWidth() {
	return width;
    }

    public void setWidth(int width) {
	this.width = width;
    }

    public int getHeight() {
	return height;
    }

    public void setHeight(int height) {
	this.height = height;
    }

    public Image getPlaneImage() {
	return planeImage;
    }

    public void setPlaneImage(Image planeImage) {
	this.planeImage = planeImage;
    }

    public boolean isAlive() {
	return isAlive;
    }

    public void setAlive(boolean isAlive) {
	this.isAlive = isAlive;
    }

    public boolean isHitDoubleLaser() {
	return hitDoubleLaser;
    }

    public void setHitDoubleLaser(boolean hitDoubleLaser) {
	this.hitDoubleLaser = hitDoubleLaser;
    }

    public List<Bomb2> getHoldBombList() {
	return holdBombList;
    }
    public List<Bomb2> getHoldBombList2() {
		return holdBombList;
        }

    public void setHoldBombList(List<Bomb2> holdBombList) {
	this.holdBombList = holdBombList;
    }

    public BulletType getBulletType() {
	return bulletType;
    }

    public void setBulletType(BulletType bulletType) {
	this.bulletType = bulletType;
    }

    public GamePlayingPanel2 getPlayingPanel() {
	return playingPanel2;
    }

    public void setPlayingPanel(GamePlayingPanel2 playingPanel2) {
	this.playingPanel2 = playingPanel2;
    }
    
    public int getHittedCount() {
    	return hittedCount;
        }

        public void setHittedCount(int hittedCount) {
    	this.hittedCount = hittedCount;
        }
        
        public void addHittedCount() {
        	this.hittedCount+=1;
            }
        
}
