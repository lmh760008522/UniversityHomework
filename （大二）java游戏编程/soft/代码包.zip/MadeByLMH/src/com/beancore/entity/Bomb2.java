package com.beancore.entity;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;


import com.beancore.config.ImageConstants;
import com.beancore.listener.BombListener;
import com.beancore.ui.GamePlayingPanel2;
import com.beancore.util.Images;

public class Bomb2{
	private int posX;
    private int posY;
    private int width;
    private int height;
    private int speed;
    
    private GamePlayingPanel2 gamePlayingPanel;
    private BombListener listener;
    private Image bombImage;

    public Bomb2(GamePlayingPanel2 gamePlayingPanel) {
	 this.gamePlayingPanel = gamePlayingPanel;
	    bombImage = Images.BOMB_IMG;
	    width = ImageConstants.BOMB_WIDTH;
	    height = ImageConstants.BOMB_HEIGHT;
	    speed = 40;
    }

    public Rectangle getRectangle() {
	return new Rectangle(posX, posY, width, height);
    }

    public void draw(Graphics g) {
	Graphics2D g2d = (Graphics2D) g;
	g2d.drawImage(bombImage, posX, posY, width, height, gamePlayingPanel);

    }

    public void addBombListener(GamePlayingPanel2 playingPanel) {
	this.gamePlayingPanel = playingPanel;
    }

    public int getPosX() {
	return posX;
    }

    public void setPosX(int posX) {
	this.posX = posX;
    }

    public int getPosY() {
	return posY;
    }

    public void setPosY(int posY) {
	this.posY = posY;
    }

    public int getWidth() {
	return width;
    }

    public void setWidth(int width) {
	this.width = width;
    }

    public int getHeight() {
	return height;
    }

    public void setHeight(int height) {
	this.height = height;
    }


    public GamePlayingPanel2 getGamePlayingPanel() {
	return gamePlayingPanel;
    }
    
    public void setGamePlayingPanel(GamePlayingPanel2 gamePlayingPanel) {
	this.gamePlayingPanel = gamePlayingPanel;
    }

    public BombListener getListener() {
	return listener;
    }

    public void setListener(BombListener listener) {
	this.listener = listener;
    }

    public Image getBulletImage() {
	return bombImage;
    }

    public void setBombImage(Image bombImage) {
	this.bombImage = bombImage;
    }

    public int getSpeed() {
	return speed;
    }

    public void setSpeed(int speed) {
	this.speed = speed;
    }
   
    public MyPlane2 hitMyPlanes() {
    	MyPlane2 myPlane = this.gamePlayingPanel.getMyPlane();
    	    if (this.getRectangle().intersects(myPlane.getRectange())) {
    		myPlane.addHittedCount();
    		return myPlane;
    	}
    	return null;
        }
}
