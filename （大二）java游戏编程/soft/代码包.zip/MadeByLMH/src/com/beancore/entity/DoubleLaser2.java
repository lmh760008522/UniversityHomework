package com.beancore.entity;

import com.beancore.config.CatchableWeaponType;
import com.beancore.ui.GamePlayingPanel2;

public class DoubleLaser2 extends CatchableWeapon2{
	public DoubleLaser2(GamePlayingPanel2 gamePlayingPanel, CatchableWeaponType weaponType) {
		super(gamePlayingPanel, weaponType);
	    }
}
