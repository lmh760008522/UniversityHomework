
#ifndef __PEEPER_WND_H__
#define __PEEPER_WND_H__

#include "../PeeperLib.h"

class CPeeperWnd;	

class CPeeperThread : public CWinThread
{
	DECLARE_DYNCREATE(CPeeperThread)
public:
	CPeeperThread();
	virtual ~CPeeperThread();
	
public:
	SIZE m_szScreen;
	CPeeperWnd *m_pPeeperWnd;

public:
	virtual BOOL InitInstance()
	{
		return TRUE;
	}

	virtual int ExitInstance()
	{
		return CWinThread::ExitInstance();
	}	
	
protected:
	afx_msg HRESULT OnMsgGetDIB(WPARAM, LPARAM);
	afx_msg HRESULT OnMsgConnect(WPARAM, LPARAM);

	//{{AFX_MSG(CGetDIBThread)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

class CPeeperWnd : public CScrollView
{
	DECLARE_DYNCREATE(CPeeperWnd)

public:
	CPeeperWnd(CWnd *pNotifyWnd = NULL);
	virtual ~CPeeperWnd();
	BOOL Create(CString strIP, UINT uPort, CWnd *pParent = NULL, 
		int nBits = -1, UINT nTimer = PL_DIB_TIMER);
public:
	static CString GetClientVersion();

public:
	int      SendData(BYTE *chData, int nLen, BYTE chFlag = PL_NONE);
	int      ReadData(BYTE *chData, int nLen, BYTE *chFlag = NULL);
	BOOL     ConnectServer();
	BOOL     CloseServer();
	BOOL     GetState(); // ״̬BOOL
	CString  GetClientInfo(); // ״̬CString
	UINT     GetConnectTime();
	char    *GetConnectInfo();
	void     SetConnectInfo(char *chInfo);
	void     SetNotifyWnd(CWnd *pNotifyWnd);
	void     SetBits(int nBits);
	void     SetUpdateSpeed(UINT nTimer);
	BOOL     CanSend();
	BOOL     IsPause();
	void     Pause();
	void     Resume();
	DWORD    SetEnableFlag(DWORD dwFlag);
	DWORD    SetEnableFlag(DWORD dwFlag, BOOL bSet);
	DWORD    GetEnableFlag();
	BOOL     GetEnableFlag(DWORD dwEvent);

	PL_ColorType GetColorType()
	{
		return m_ctColor; 
	}
	PL_ColorType SetColorType(PL_ColorType ct)
	{
		PL_ColorType old = m_ctColor;
		m_ctColor = ct;
		return old;
	}
	PL_ZipType GetZipType()
	{
		return m_ztZip; 
	}
	PL_ZipType SetZipType(PL_ZipType zt)
	{
		PL_ZipType old = m_ztZip;
		m_ztZip = zt;
		return old;
	}

public: // tools function
	BOOL T_RunCommand(char *chCommand);
	BOOL T_SendMsg(char *chMsg, UINT uType);
	BOOL T_ExitWindow(UINT uType);
	BOOL T_LockDesktop(BOOL bLock);
	BOOL T_CopyFileToRemote(char *chFileSrc, char *chFileDes, HWND hNotifyWnd = NULL);
	BOOL T_CopyFileFromRemote(char *chFileSrc, char *chFileDes, HWND hNotifyWnd = NULL);
	BOOL T_DeleteFile(char *chFile);
	BOOL T_MoveFile(char *chFileSrc, char *chFileDes);

protected:
	POINT   GetMousePoint(BYTE *chData = NULL);
	BOOL    ExitConnect();
	void    DrawDIB();
	int     SendDIBBits();
	int     GetScreenSize(); //������������
	CPoint  GetOffsetPos(BOOL bScroll = TRUE);

public:
	UINT    m_uPort; //�˿ں�
	CString m_strIP; //������IP
	HDIB    m_hDib;  //����ͼ��
	SOCKET  m_sckClient[2]; //�ͻ���Socket

protected:
	PL_ColorType m_ctColor; //��ɫ��
	PL_ZipType   m_ztZip;   //ѹ������

	BOOL m_bIsConnect;

	DWORD m_dwEnableFlag;
	CWnd *m_pNotifyWnd;
	CDC m_memDC;
	SIZE m_szScreen;
	UINT m_nTimerID;
	int m_nBits;
	UINT m_nSpeed;
	UINT m_nRetryTime;
	BOOL m_bIsDoing;
	char m_chConnectInfo[512];
	CPeeperThread m_hPeeperThread;
	BOOL m_bIsPause;
	int m_nLastUpdateTime;
	CString m_strState;
	UINT m_nConnectTime;
	//{{AFX_VIRTUAL(CPeeperWnd)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void OnDraw(CDC* pDC);
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

protected:
	afx_msg HRESULT OnMsgPeeperThread(WPARAM wParam, LPARAM lParam);
	//{{AFX_MSG(CPeeperWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // __PEEPER_WND_H__
