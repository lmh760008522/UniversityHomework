// Զ�̿�������-͵����  ������

#ifndef __PEEPER_FRAME_H__
#define __PEEPER_FRAME_H__

#include "../PeeperMenu.h"

class CMainClientWnd : public CWnd
{
public:
	CMainClientWnd();
	virtual ~CMainClientWnd();
	BOOL SetBkBitmap(HBITMAP hBmp, BOOL bStretch = FALSE);
	BOOL PaintBmp();

protected:
	CDC	 m_memDC;
	SIZE m_szBmp;
	BOOL m_bStretch;

public:
	//{{AFX_VIRTUAL(CMainClientWnd)
	//}}AFX_VIRTUAL
protected:
	//{{AFX_MSG(CMainClientWnd)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)
public:
	CChildFrame();
	virtual ~CChildFrame();

public:
	//{{AFX_VIRTUAL(CChildFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL
protected:
	//{{AFX_MSG(CChildFrame)
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMDIActivate(BOOL bActivate, CWnd* pActivateWnd, CWnd* pDeactivateWnd);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class CPeeperBar : public CDialogBar
{
public:
	CPeeperBar();
	virtual ~CPeeperBar();
public:
	//{{AFX_VIRTUAL(CPeeperBar)
	//}}AFX_VIRTUAL
protected:
	//{{AFX_MSG(CPeeperBar)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

class CPeeperWnd;
class CPeeperClientDoc;

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();
	virtual ~CMainFrame();
	CChildFrame *GetCurFrame();
	CPeeperWnd *GetCurPeeperWnd();
	CPeeperClientDoc *GetCurPeeperDoc();

public:
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL
public:
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
	CPeeperBar  m_wndCommand;
	CPeeperBar  m_wndFile;
	CPeeperBar  m_wndComputer;
	CToolBar    m_wndDibView;
// for full screen
	CRect       m_rcOldRect;
	int         m_nOldCmdShow;
	BOOL        m_bIsFullScreen;
	CMainClientWnd m_wndClientWnd;

protected:
	CPeeperMenu m_hPeeperMenu;
	CPeeperMenu m_hPeeperClientMenu;
	CPeeperMenu m_hPeeperSysMenu;

public:
	BOOL PeeperMenuAttach(HMENU hMenu);
	BOOL PeeperClientMenuAttach(HMENU hMenu);

	void OnExecCommand();
	void OnExecComputer();
	void OnExecFile();
	void OnFullScreen();
	void OnFileClose();
	void OnFileNew();
	int  GetClientCount();

protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnMenuCommand();
	afx_msg void OnUpdateMenuCommand(CCmdUI* pCmdUI);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //__PEEPER_FRAME_H__
