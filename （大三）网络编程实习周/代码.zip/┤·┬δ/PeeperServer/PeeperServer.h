#ifndef __PEEPER_APP_H__
#define __PEEPER_APP_H__

#include "resource.h"

class CPeeperServerApp : public CWinApp
{
public:
	BOOL Register();
	CPeeperServerApp();
	//{{AFX_VIRTUAL(CPeeperServerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL
	//{{AFX_MSG(CPeeperServerApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
#endif // __PEEPER_APP_H__
